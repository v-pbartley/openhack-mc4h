

# Templates are currently Depricated - new ones will be made avaliable soon 

do not use the templates until they are updated 

Ask from community 

My key takeaways are

3 option deployment is needed

option 1 = fhir + proxy + sync agent

option 2 = proxy + sync agent

option 3 = sync agent

customers should be able to use existing kv or deploy a new one as part of option 1 or 2 (option 3 will use kv from 1 or 2)

samples for testing is a must have

we still need a distribution flow / approval process for getting sync agent into the field safely (punting to FastTrack)


# Readme.md

Template purpose and order of execution 

## Prerequisites 

These scripts will gather (and export) information necessary to the proper operation of the FHIR-SyncAgent and will store that information into the FHIR-Proxy Keyvault.  
 - Prerequisites:  Azure API for FHIR a
 - Prerequisites:  FHIR-Proxy must be installed along with the createproxyserviceclient.bash script


## Deploy template (from GitHub)
To deploy an external template, provide the URI of the template exactly as you would for any external deployment. The external template could be in a GitHub repository or and an external storage account.

Open the Cloud Shell prompt.

To deploy the template, use the following commands:

```azurecli
az group create --name ExampleGroup --location "Central US"

az deployment group create \
  --name ExampleDeployment \
  --resource-group ExampleGroup \
  --template-uri "https://github.com/daemel/fhir-cds-agent/blob/deployment-updates/templates/fhir-SyncAgent.template.json" \
  --parameters storageAccountType=Standard_GRS
```

## Deploy template (from cloned i.e., local repo)


To deploy the template, use the following commands:

```azurecli
az group create --name ExampleGroup --location "South Central US"

az deployment group create \
  --resource-group ExampleGroup \
  --template-file azuredeploy.json \
  --parameters storageAccountType=Standard_GRS
```


