# DEPRICATED _ DO NOT USE 


FHIR CDS Agent Deployment

## FHIR Sync Agent Premises & Guidelines 
__NOTE:__ The FHIR Sync Agent does not interact with any electronic medical record (EMR) system directly. The FHIR Sync Agent does not read data from an EMR system and does not write data to an EMR system. 

- Data synchronization is triggered by an event or a message. Data exchange occur quickly, not real time.
- Only metadata is stored in the service bus queue. No FHIR or patient health information (PHI) is stored in any service bus queue.
- The FHIR Sync Agent assumes that all patient data originates from Azure API for FHIR. The sync agent does not prevent you from creating patients in Dataverse (for example, in Patient Access).
- Only a subset of FHIR data is synchronized between Azure API for FHIR and Dataverse.
- You can turn off or turn on which elements to sync. By default, patient (contact) records in Dataverse are enabled for synchronization. For all other data, do not sync the data if you do not need it in FHIR. 
- Only a patient resource is sent to and populated in Dataverse. All patient clinical and financial data, such as encounters, observations, and appointments, are sent to Dataverse after patient consent. All subsequent data changes for consented patients are synchronized automatically. This reduces the amount of FHIR data that is synchronized with Dataverse.

## Setup 
Setup begins with Service Client setups in the respective Azure and Dynamics tenants.   

__Azure AD Tenant (FHIR Sync Agent)__ - a Service Client ID and Secret must be setup for FHIR-Proxy (a script for this is provided in the FHIR-Proxy repo).

__Dynamic AD Tenant (FHIR Sync Administration)__ - a Service Client ID must be setup and entered into the Dataverse Environment Variables to prevent circular synchronization issues.  This Service Client ID must be supplied to the FHIR Sync Agent as part of the setup.  Use the setupSyncAgent.bash script to enter the Datavers information into Azure KeyVault setup by FHIR-Proxy.     

### Step 1. Prerequisites 
- Ensure Azure API for FHIR is installed and functional 
- Ensure Microsoft [FHIR-Proxy](https://github.com/microsoft/fhir-proxy) is installed with Keyvault
    - run the [createproxyserviceclient.bash](https://github.com/microsoft/fhir-proxy/blob/main/scripts/createproxyserviceclient.bash) to setup Auth 
- Ensure Microsoft [FHIR-Loader](https://github.com/microsoft/fhir-loader) is installed and functional (use the FHIR-Proxy Keyvault)

__NOTE__  FHIR-Proxy has a [createpostmanproxyenv.bash](https://github.com/microsoft/fhir-proxy/blob/main/scripts/createpostmanproxyenv.bash) that will create a Postman Environment that will connect to Azure API for FHIR


### Step 2.
There are two approaches to installing the FHIR-SyncAgent 

#### Option 1.  Azure CLI- Bash shell scripts
Scrpts are maintained in the ./scripts directory.  A [gettingStarted.md](https://github.com/microsoft/fhir-cds-agent/blob/main/scripts/gettingStarted.md) is available in the directory with detailed instructions. 

First - [deploySyncAgent.bash](https://github.com/microsoft/fhir-cds-agent/blob/main/scripts/deploysyncagent.bash).  This script installs the core Azure components 

Second - [setupSyncAgent.bash](https://github.com/microsoft/fhir-cds-agent/blob/main/scripts/setupSyncAgent.bash).  This script applies the Dataverse Client information and exports the Dataverse Environment settings needed for connection to the SyncAgent. 

Third - [controlSyncAgent.bash](https://github.com/microsoft/fhir-cds-agent/blob/main/scripts/controlSyncAgent.bash).  This script applies the FHIR-Proxy Post Process Module to enable SyncAgent communication. 

#### Option 2.  Azure Resource Manager (ARM) Template  
Templates are maintained in the ./templates directory.  A [Readme.md](https://github.com/microsoft/fhir-cds-agent/blob/main/templates/Readme.md) is available in the directory with detailed instructions. 

TBD




## Components of the FHIR-CDS-Agent
Each component includes a description of how it is used as part of the solution.
  
- Azure Key vault - Safeguards connection secrets used by the Azure Funcation
- Azure Services Bus - Maintains the ordered queues for processing messages/event. There are 2 queues.
  - cdsupates - This queue is for messages from Dynamics CDS to the FHIR Service. It is responsible for maintaining ordering and temp storage of messages while inflight. These messages do not store PHI or PII. The messages have an id for the function to use for pulling data from CDS and pushing to the FHIR service.
  - fhirupdates - This queue is for messages from the FHIR Service going to Dynamics CDS. It is responsible for maintaining ordering and temp storage of messages while inflight. These messages do not store PHI or PII. The messages have an id for the function to use for pulling data from FHIR and pushing to the CDS service.
- Azure App Service Plan - the compute plan for the Azure Function.
- Azure Function - Message/Event Processor. There are three functions in the function app.
  - FHIRNDJsonFileLoader - Used to bulk load the data from the API for FHIR or FHIR Server for Azure to the Dynamics CDS. These loads are not continuous. They are planned. For example this process would be used to seed patients in Dynamics CDS.
  - ProcessingCDSUpdates - Used to load messages from Dynamics CDS via the cdsupdates queue to the API for FHIR or FHIR Server for Azure on an ongoing basis.
  - ProcessingFHIRUpdates - Used to load messages from the API for FHIR or FHIR Server for Azure via the fhirupdates queue to the Dynamics CDS on an ongoing basis.
  - Default SKU: none, part of App Service Plan
- Azure Storage - Used for the staging the ndjson files for the bulk loading Dynamics CDS via the Azure Function FHIRNDJsonFileLoader. Also used as the storage location for the Azure Function typical processing needs.
  - Default SKU: Locally-redundant storage (LRS)
- Application Insights - Central logging of the Azure Function message/event processing.
  - Default SKU: none, only one SKU for this service



- can I create a single template for all these elements ?

1) Install the Azure API for FHIR via the portal as your first step
2) Install the FHIR Proxy in the same resoure group at the FHIR Service
3) Install the fhir-cds-agent in the same resource group as the Azure API for FHIR\FHIR Server and FHIR Proxy

options 


API FHIR-Starter (https://github.com/sordahl-ga/api4fhirstarter)
FHIR-Proxy - deployfhirproxy.bash(use keyvault from FHIR-Starter) (https://github.com/microsoft/fhir-proxy)
FHIR-Proxy - createserviceclient.bash (use KV from FHIR-Starter) (https://github.com/microsoft/fhir-proxy)
FHIR-Loader - deploybulkloader.bash (use KV from FHIR-Starter) (https://github.com/microsoft/fhir-loader)

dale to add samples into the loader, proxy and sync agent app (along with readme)
dale to add in smart web app 

FHIR-SyncAgent - deploysyncagent.bash (use KV from FHIR-Starter) (https://github.com/microsoft/fhir-cds-agent
)
FHIR-SyncAgent - setupSyncAgent.bash (use KV from FHIR-Starter) (https://github.com/microsoft/fhir-cds-agent
)
FHIR-SyncAgent - controlSyncAgent.bash (use KV from FHIR-Starter) (https://github.com/microsoft/fhir-cds-agent
)


### END 





Depricated from here down 

The fhir-cds-agent deployment is the installation and configuation of the fhir-cds-agent. This agent should be used when syncornising data between the Azure API for FHIR & Microsoft Cloud for Health or FHIR Server for Azure & Microsoft Cloud for Health.

The deployment has been split into two parts. Part 1 deploys the Azure services and Azure function code necessary to run the sync agent. Part 2 will setup the RBAC permissions between the Azure Function and Azure API for FHIR or FHIR Server. The reason for this separation is because setting RBAC permissions in most organization is set by a different resource than who deploys a script.

Part 1 of the deployment is an ARM template. This ARM Template can be deployed via a script or uploaded to the Azure Portal as a Custom Template. A parameters file is included in repository to assist with deployment via a local script.

Part 2 of the deployment is either Azure CLI or PowerShell script or manual. Instructions have been included for both.



## Best Practices Order of installation








## Prerequisites

  
### Prerequisites for deployment

For deploying locally and/or RBAC permissions:

1) Azure CLI 2.13 or greater installed
2) optional PowerShell 5.1 or greater of PowerShell 5.1

### Setup Part One (1) ARM deployment

#### Deploying from local host

1) Clone repo
2) Fill out the values in the fhir-cds-agent.parameters.json file
3) Use your preferred scripting method to deploy fhir-cds-agent.template.json and fhir-cds-agent.parameters.json files. This deployment should take about 5 minutes.
4) Use one of the MSIScripts to set the RBAC permissions from the Azure Function to Azure API for FHIR or FHIR Server. This step may have to be performed by a customer's global admin. See below for the correct file to use or for the manual steps.

#### Deploying from Azure portal via custom template

1) Clone repo
2) Upload the fhir-cds-agent.template.json file to the custom template in the Azure portal
3) Fill in the necessary parameters values
4) Review and Create
   1) NOTE: Common Errors for the 'Review' are:
      1) Subscription has reached the max allowed Premium App Services
      2) The Azure region is limited Premium App Services
5) Post deployment use local scripting engine or the Azure Cloud shell to set the RBAC permissions. This step may have to be performed by a customer's global admin. See below for the correct file to use or for the manual steps.

#### Template Parameters

If deploying from a script you will need to fill out the fhir-cds-agent.parameters.json file. Here is description and example of each parameter.

- **fhirCdsAgentAppName** - This will be the name of the Azure Funcation and the base name for the other services which get installed. Name needs to be between 2-30 lowercase alphanumberic characters. No hyphens.
- **installLocation** - The Azure region where the fhir-cds-agent services will be installed. Default Value is East US.
- **fhirProxyKeyvault** - The name of key vault service installed with the fhir proxy. Only the name not the URL.
- **fhirProxyAppName** - The name of the funcation app installed with the fhir proxy. Only the name not the URL.
- **cdsInstance** - The Dynamics instance URL. Needs to include the "https://". Format will look like "https://instance-name.crm.dynamics.com". This value will be stored as a configuration value in the Azure Function.
- **cdsTenantID** - The GUID of the Dynamics instance the fhir-cds-agent will connect to. Should be in this format aaaaaaa-1111-bbbb-2222-cccccccccc. This value will be stored as a configuration value in the Azure Function.
- **cdsClientID** - The client GUID of the Dynamics service principle used to by the Azure Funcation for connecting. Should be in this format aaaaaaa-1111-bbbb-2222-cccccccccc. This value will be stored as a configuration value in the Azure Function.
- **cdsClientSecret** - The client Secret of the Dynamics service principle. It will be referenced by the Azure Function. This value will be stored in Azure Key vault. Access policy for the Azure Function is set as part of the script. Format of the secret is typically alphanumberic upper and lowercase with a symbols mixed in.

### Setup Part Two (2) Script Deployments

There are two scripts which need to be deployed. One for the Azure Function binaries and one for RBAC of the Azure Function to the Proxy

#### Deploy the Azure Fuction Binaries

For this deployment you will need to have the AZ CLI installed. Version 2.13 or newer.

Open your command line tool
Change directories to the location of the cloned repo
Run the following script with the your values for the parmeters. Your parameters for this script are:

- subscription-name or ID - name of subscription where ARM template was deployed
- group-name - Resource group name where the ARM template was deployed
- syncagentname - same name used for the ARM template parameters

```cmd
az login

az account set --subscription <subscription-name or ID>

az functionapp deployment source config-zip --resource-group <group-name> --name <syncagentname> --src .\DynamicsCDSSyncAgent.zip
```

#### Set RBAC permisssions

#### Option 1 - Azure RBAC scripts

Here is the script nessessary to set the RBAC permission of the Azure Fuction to the FHIR proxy. There are two scripts listed. You only need to use one of them. One is Bash and the other is PowerShell.

This script can be give to an Azure Administrator with the required permissions to run on your behalf.

The parameters needed to run this script are:

- subscription-name or ID - name of subscription where ARM template was deployed
- rgname - Resource group name where the ARM template was deployed
- syncagentname - same name used for the ARM template parameters
- subname - name of subscription where ARM template was deployed
- fhirproxyname - Name only of the FHIR Proxy. This would be the first part of the URL between https:// and .azurewebsites.net

Bash with AZ CLI:

```bash

az login

az account set --subscription <subscription-name or ID>
```

```bash
declare syncagentappname=""
declare subname=""
declare rgname=""
declare fhirproxyname=""
declare agentrole="Contributor"

#get azure function managed idenity
declare syncagentafobjectid=$(az resource list -n $syncagentappname --query [*].identity.principalId --out tsv)

#cli commands -- grant sync agent permission to access fhir api
declare fhircdsagentscope ='/subscriptions/' + $subname + '/resourceGroups/' + $rgname + '/providers/Microsoft.Authorization/roleAssignments/' + $fhirproxyname
az role assignment create --role $agentrole --assignee-object-id $syncagentafobjectid --assignee-principal-type ServicePrincipal --scope $fhircdsagentscope
```

PowerShell with AZ CLI

```powershell
az login

az account set --subscription <subscription-name or ID>

$syncagentappname=""
$subname=""
$rgname=""
$fhirproxyname=""
$agentrole="Contributor"

#get azure function managed idenity
$syncagentafobjectid=$(az resource list -n $syncagentappname --query [*].identity.principalId --out tsv)

#cli commands -- grant sync agent permission to access fhir api
$fhircdsagentscope ='/subscriptions/' + $subname + '/resourceGroups/' + $rgname + '/providers/Microsoft.Authorization/roleAssignments/' + $fhirproxyname
az role assignment create --role $agentrole --assignee-object-id $syncagentafobjectid --assignee-principal-type ServicePrincipal --scope $fhircdsagentscope

```

#### Option 2 - Azure RBAC Manual Steps

- Open the Azure portal
- Navigate to the App Service for the FHIR Proxy.
- Once in the service, locate and open 'Access Control (IAM)'
- Navigate to add a role assignment under Add
- On the Add role assignment blade choose the role 'Contributor' FHIR Proxy.
- Leave the default for Assign access to
- On the Select box enter the name of the Azure Function you want to grant access to. This should be the name of the syncAgentAppName from the parameters.
- Click Save


## Known Issues

There are no known issues at this time.

In the event you run into an issue, please make a submission on the Issues page. Feedback is also welcome.
