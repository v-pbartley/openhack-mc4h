# What is FHIR

## Introduction 
FHIR® – [Fast Healthcare Interoperability Resources](hl7.org/fhir) – is a next generation standards framework created by HL7. FHIR combines the best features of HL7's v2 , HL7 v3  and CDA  product lines while leveraging the latest web standards and applying a tight focus on implementability.

FHIR solutions are built from a set of modular components called "Resources". These resources can easily be assembled into working systems that solve real world clinical and administrative problems at a fraction of the price of existing alternatives. FHIR is suitable for use in a wide variety of contexts – mobile phone apps, cloud communications, EHR-based data sharing, server communication in large institutional healthcare providers, and much more.

## Benefits
FHIR offers many improvements over existing standards:

- A strong focus on implementation: fast and easy to implement (multiple developers have had simple interfaces working in a single day)
- Multiple implementation libraries, many examples available to kick-start development
- Specification is free for use with no restrictions
- Interoperability out-of-the-box: base resources can be used as is, but can also be adapted as needed - which happens a lot - for local requirements using Profiles, Extensions, Terminologies and more
- Evolutionary development path from HL7 Version 2 and CDA: standards can co-exist and leverage each other
- Strong foundation in Web standards: XML, JSON, HTTP, OAuth, etc.
- Support for RESTful architectures, seamless exchange of information using messages or documents, and service-based architectures
- Concise and easily understood specifications
- A human-readable serialization format for ease of use by developers
- Ontology-based analysis with formal mapping for correctness (under development)

## Microsoft FHIR Service 
The FHIR service in the Azure Healthcare APIs enables rapid exchange of data through Fast Healthcare Interoperability Resources (FHIR®) APIs, backed by a managed Platform-as-a Service (PaaS) offering in the cloud. It makes it easier for anyone working with health data to ingest, manage, and persist Protected Health Information PHI in the cloud:

- Managed FHIR service, provisioned in the cloud in minutes
- Enterprise-grade, FHIR-based endpoint in Azure for data access, and storage in FHIR format
- High performance, low latency
- Secure management of Protected Health Information (PHI) in a compliant cloud environment
- SMART on FHIR for mobile and web implementations
- Control your own data at scale with role-based access control (RBAC)
- Audit log tracking for access, creation, modification, and reads within each data store

The FHIR service allows you to create and deploy a FHIR server in just minutes to leverage the elastic scale of the cloud. The Azure services that power the FHIR service are designed for rapid performance no matter what size datasets you’re managing.

The FHIR API and compliant data store enable you to securely connect and interact with any system that utilizes FHIR APIs. Microsoft takes on the operations, maintenance, updates, and compliance requirements in the PaaS offering, so you can free up your own operational and development resources.

### Next Steps 

[Mapping with MC4H](./mapping.md) 
 