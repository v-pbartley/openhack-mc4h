# FHIR-SyncAgent Sizing 

FHIR-SyncAgent sizing for Microsoft Cloud for Healthcare is adjustable via App Service Plans and by increasing Service Bus tiers.  Out of the box sizing is set to handle 1M patient loads per hour.  For workloads beyond that customers should:

- scale their App Service Plans to 10 CPUs each
- enable Autoscaling on the FHIR Service (up to 100K RU's)
- change the Service Bus from Standard to Premium 

## Component Deployments
![high-level-sizing](./images/architecture/Sizing.png)


## Component List

Azure Component       | Service                     | Size 
----------------------|-----------------------------|-----------
FHIR Component Shared |	Key vault                   | Standard
FHIR-Loader	          | Storage account	            | Standard LRS
FHIR-Loader	          | Event Grid System Topic     | Basic
FHIR-Loader           | App Service plan (Windows)  | B1 – 2 workers
FHIR-Loader	          | Application Insights        | Data costs
FHIR-Loader	          | Function App                | Compute costs
FHIR Service          | Azure API for FHIR          | 1,000 RU’s
FHIR-Proxy            | App Service plan (Windows)  | B1 – 2 workers
FHIR-Proxy            | Azure Cache for Redis       | Basic
FHIR-Proxy            | Storage account             | Standard LRS
FHIR-Proxy            | Application Insights        | Data costs
FHIR-Proxy            | Function App                | Compute costs
FHIR-SyncAgent        | Application Insights        | Data costs
FHIR-SyncAgent        | Function App                | Compute costs
FHIR-SyncAgent        | App Service plan (Windows)  | B1 – 2 workers
FHIR-SyncAgent        | Service Bus Namespace	    | Standard
FHIR-SyncAgent 	      | Storage account	            | Standard LRS


