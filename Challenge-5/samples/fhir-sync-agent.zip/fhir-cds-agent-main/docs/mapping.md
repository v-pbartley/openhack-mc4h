# Mapping with Microsoft Cloud for Healthcare

Bringing together capabilities from Microsoft Dynamics 365, Microsoft 365, and Microsoft Azure, Microsoft Cloud for Healthcare (MC4H) expedites a healthcare organization’s ability to roll out solutions. 

## Sync Agent Mapping Attributes Guide

The entity attribute mapping definitions on Dataverse contain a fhir mapping field that defines how to retrieve a value from a FHIR property to send to Dataverse as well as how to update/create a FHIR property from a Dataverse Attribute.  These mapping definitions are contained in a serialized JSON object, this object contains entries to support JSON Path selection for retrieving and updating existing property values as well as definitions for creating new JSON Properties on the FHIR Object that do not exist or need to be inserted.
 

# JSON Object Definition
```al
{
	"s": "", //<A valid JSON Path expression used to select an existing JSON Property of the FHIR Resource to extract/set values from/to Dataverse,
	"c": { //<JSON property fields used  to insert/create JSON Properties when the select path is non-existent in the resource JSON Object >,
			"p": "", //<The parent JSON Property name to Create>.
			"a": [ //<Array of attributes to set on the selected JSON Property
				""
			]
}
```

# Examples

### Simple String Existing Field
The following would get lastname from FHIR to send to Dataverse or update lastname attribute value from Dataverse to FHIR:

```al
{"s": "$.name[?(@.use=='usual')].family"}
```

This mapping assumes that the node always exists and can be located via the JSON Path defined on the fhir resource

### Existing or Non-Existing Field
The following would get/update the city field of address[0] if it exists, if this was an update from Dataverse and address[0] did not exist it would create an address[0] parent and set the city value from Dataverse it would also create placeholder/default values for other attributes 

```al
{
	"s": "$.address[0].city",
	"c": {
		"p": "address[0]",
		"a": [
			{
				"line": ["x"]
			},
			{
				"city": "%"
			},
			{
				"state": "x"
			},
			{
				"postalCode": "x"
			},
			{
				"country": "x"
			}
		]
	}
}
```

__Note:__ For string values the value set is the literal defined in the attribute array unless it is one of the special character sequences, these will be replaced with values indicated below:
1. % - Copy the value of the Dataverse Attribute
2. %% -  Copy the type of the FHIR Reference Resource (e.g. Patient)
3. %%% - Copy the type and resource id of the FHIR Reference Resource (e.g. Patient/1234) 

### Patient Name 
Applying the rules above, we can use the following to:

- "s" =  extract a Patient given name to load into Dataverse
- "c" = create a Patient given name when not in FHIR
    - "p" = parent object of the entry to create
    - "a" = array parameters to use when creating "c"

```al
{"s": "$.name[?(@use=='official')].given[0]", "c": {"p": "name[0]",  "a": [{"use": "official"}, {"family": "x"}, {"given[0]": "%"}]} }
```

__Note__:  the brackets {} contain the expression, while the commas "," separate the expression segments, however the array bracket [] means the expression above contains 2 complete segments 

```al
"s": "$.name[?(@use=='official')].given[0]"
``` 
and

```al
"c": {"p": "name[0]",  "a": [{"use": "official"}, {"family": "x"}, {"given[0]": "%"}]
```

### Codeable Concpet
Matching Codeable Concepts is essentially the same as matching JSON string elements, the only difference being there is an additional level needed to get to the detail. 

1.	URL of the extension is http://hl7.org/fhir/StructureDefinition/patient-religion
2.	We want to access the valueCodeableConcept element inside this extension entry
3.	We want the first entry in the coding array
4.	We want to map the display to show the information in FHIR that is attached to a coding system

FHIR Resource 
![mapping_example1.png](./images/mapping/mapping_example1.png)


JSON Path
![mapping_example0.png](./images/mapping/mapping_example0.png)


## Text Example (religion)
1.	URL of the extension is http://hl7.org/fhir/StructureDefinition/patient-religion
2.	We want to access the valueCodeableConcept element inside this extension entry
3.	We want to map the text to show the information given to FHIR by Epic

FHIR Resource 
![mapping_example2.png](./images/mapping/mapping_example2.png)


JSON Path
![mapping_example3.png](./images/mapping/mapping_example3.png)

# Current Limitations
1. No dynamic array insertion/creation positions must be absolute, selection is dynamic using JSON Path
2. Value data must be valid in JSON for the destination attribute UTF-8 strings, JSON UTC Dates, booleans, etc...

# Tools
There are multiple tools that can be used to test JSON Path strings  
[JSONPath Online Evaluator](https://jsonpath.com) 
 
[JSON Escape / Unescape](https://codebeautify.org/json-escape-unescape) 

[JSON Path Extension for VSCodese](https://marketplace.visualstudio.com/items?itemName=weijunyu.vscode-json-path)

Read more here https://github.com/stedolan/jq/wiki/For-JSONPath-users 



