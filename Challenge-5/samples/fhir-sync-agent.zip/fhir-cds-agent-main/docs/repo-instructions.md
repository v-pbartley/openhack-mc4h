# How to use this repo

## Personal Access Tokens 
To clone the private microsoft/fhir-cds-agent repo users must use a Private Access Token.  GitHub instructions for creating a token can be found here https://docs.github.com/en/free-pro-team@latest/github/authenticating-to-github/creating-a-personal-access-token, or see examples below. 
   
Note that because Microsoft uses SSO, you will have to authorize the token to work with SSO. 

Go to Account -> Settings 
![Account Settings](/docs/images/repo/repo-settings.png)

Settings to -> Developer Settings 
![Account Settings](/docs/images/repo/developer-settings.png)

Developer Settings -> Personal Access Tokens - Generate new token
![Account Settings](/docs/images/repo/developer-token.png)

![Account Settings](/docs/images/repo/password.png)

![Account Settings](/docs/images/repo/sso.png)


## Cloning the repo
git clone https://github.com/microsoft/fhir-cds-agent
Username for 'https://github.com': yourname@microsoft.com
Password for 'https://yourname@microsoft.com@github.com': <enter your Personal Access Token>
remote: The `microsoft' organization has enabled or enforced SAML SSO. To access
remote: this repository, visit https://github.com/enterprises/microsoftopensource/sso?authorization_request=AGHNJI…. 
remote: and try your request again.

After SSO is enabled it will download / clone

