# FHIR-SyncAgent

The FHIR-SyncAgent is designed to keep selected FHIR Resources in sync with Dataverse.  The control and mapping features are managed within Dataverse - Microsoft Cloud for Healthcare Administration applications. 

![high-level-data-flow](./images/mapping/mapping-data-flow.png)


## Documents
The documents in this directory are designed to help users provision and test a FHIR-SyncAgent deployment.

- [What is FHIR](./FHIR.md)
- [Mapping](./mapping.md)
- [Testing Data Flows](./testing-data-flows.md)
- [Repo Instructions](./repo-instructions.md)
- [Sizing](./sizing.md)


## Resources Enabled by Default

Customers can change these defaults by editing the FHIR-SyncAgent Application Congiruation SA-FHIRMAPPEDRESOURCES

US Core R4 Resources | FHIR  | Dataverse
---------------------|-------|----------
Patient              | yes   | yes 
Encounter            | yes   | yes 
Device               | yes   | yes 
Observation          | yes   | yes 
Appointment          | yes   | yes  
MedicationRequest    | yes   | yes  
AllergyIntolerance   | yes   | yes   
Procedure            | yes   | yes  
Organization         | yes   | yes  
Location             | yes   | yes  
RelatedPerson        | yes   | yes  
Claim                | yes   | yes  
DiagnosticReport     | yes   | yes  
Condition            | yes   | yes  
Medication           | yes   | yes  
CarePlan             | yes   | yes  
Slot                 | yes   | yes  
Schedule             | yes   | yes  
CareTeam             | yes   | yes  
Practioner           | yes   | yes  

## Testing overview 

Sample test data is proviced in the ./samples directory.  Additionally synthea data can be used, but note that non-printable characters will not be loaded, nor will resource bundles with more than 500 Resource entries be loaded.   

Testing process 
- validating JSON paths / parsing 
- validating FHIR Element to Attribute Type
- validating Lookup Tables and Codeable concepts have the required US Core entries / references 
- testing US Core data end to end from both Loader and from Postman going directly against the Proxy
- testing write back using Postman for reading
   





