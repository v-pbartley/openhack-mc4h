# Testing MC4H
This document is designed to help users walk through data testing once the FHIR-SyncAgent has been deployed and the Dynamics Instance has been configured with the appropriate ServiceBus Queue information. 

## Errata 
No known issues at this time 


## Sample Data 
Patient samples are provided for testing in the ../samples directory.  Samples are provided for both Postman and the [FHIR-Loader](https://github.com/microsoft/fhir-loader) applicaiton.

---

Step 1. Load Patient Data into FHIR 

Proxy - 


FHIR-Loader - 


---
## Testing Sync with FHiR-SyncAgent (Azure)




---

## Testing Sync within MC4H
Login to Dynamics - Select FHIR Sync Agent Administration 

![login-fhir-admin](../docs/images/testing/login-fhir-admin.png)

Ensure that the FHIR Resource you want to sync is Enabled (Is Disabled is set to No).  In the example below the Patient Resource is set to sync, while all others are Disabled. 

![login-fhir-admin](../docs/images/testing/admin-resource-enabled.png)

Select the Resource and select Edit to view the Attribute maps and sync details 

![login-fhir-admin](../docs/images/testing/admin-resource-edit.png)


From the Entity Details page you can 
![login-fhir-admin](../docs/images/testing/admin-entity-details.png)


__NOTE__ Pending the Expansion map updates (see Errata), you may have to update your maps manually.  


### Update Identifiers
To update Identifiers, select Identifiers and click on Edit

![edit-entities](../docs/images/testing/admin-edit-identifiers.png)

Select msemr_medicalidentifier

![edit-entities](../docs/images/testing/msemr_medicalidentifier.png)

Select msemr_identifiersystem, type and value and edit them as per the table below (respectively)

![edit-entities](../docs/images/testing/edit-identifiers.png)


Name                    | Old value          | New values              
------------------------|--------------------|-----------------------------------------
msemr_identifiersystem  | $.system           | $.identifier[\*].type[coding[\*]].system
msemr_type              | $..coding[0].code  | $.identifier[\*].type[coding[\*]].code
msemr_value             | $.value            | $.identifier[\*].value

 

