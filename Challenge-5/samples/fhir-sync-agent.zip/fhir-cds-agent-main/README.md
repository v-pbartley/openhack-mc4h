# FHIR-SyncAgent

## Introduction

The goal of the **FHIR-SyncAgent** is to sychronize health data between Azure API for FHIR and Dataverse' Microsoft Cloud for Healthcare securely and seemlessly.  Applications built on the Dynamics platform (which includes Dynamics Model applications) or makes use of Dataverse can operate without needing to make REST API calls directly to Azure API for FHIR.  In addition to running Microsoft Cloud for Healthcare solutions, developers can also take advantage of the Dynamics' low-code/no-code environment to construct solutions/applications that can read & write healthcare related data to the Azure API for FHIR.

Development Platforms supported 

- Power Platform Canvas applications
- Power Automate
- Logic Apps
- Model Apps
- Dynamics Portal applications


## FHIR-SyncAgent Details

### Components 

![high level architecture](/docs/images/architecture/BigPicture.png)

### Reference Architecture

![Reference Architecture](/docs/images/architecture/Reference.png)

## Repository Contents 
The table below lists items contained within this repository 

Directory       | Contains                                                
----------------|--------------------------------------------------
main            | Readme, Security and compliance documents 
distribution    | Binary distribution 
docs            | Mapping and Testing documents  
samples         | Synthea generated Patient files used for testing  
scripts         | Readme + Deployment, Setup and Control scripts  
templates       | ARM Templates (__depricated until further notice__)


## Deployment
The FHIR-Sync Agent scripts are designed for and tested from the Azure Cloud Shell - Bash Shell environment.  The following services are required as part of the **FHIR-SyncAgent** --  detailed deployment instuctions are located in the [Readme.md](./scripts/Readme.md) within the scripts directory.

1) Azure Active Directory
2) Azure Storage
3) Azure Service Bus
4) Azure Functions
5) Azure Key Vault
6) Azure Application Insights

The **FHIR-SyncAgent** depends on other Microsoft technologies, specifically

1) Azure API for FHIR
2) Micorosft Dynamics

If you are ready to continue, you can find the repo cloning instructions [here](./docs/repo-instructions.md), and deployment documentation [here](./scripts/Readme.md)


## Tracking Changes & Updates
We continue to monitor questions, feature requests and of course, bugs/issues.   You can review the issues list [here](https://github.com/microsoft/fhir-cds-agent/issues)

If you are interested in receiving notifications when we publish updates to the FHIR CDS Sync Agent then please follow this repo. 

## Resources
The following is a list of references that might be useful to the reader

* [Azure for the healthcare industry](https://azure.microsoft.com/en-us/industries/healthcare/)
* [Azure API for FHIR](https://azure.microsoft.com/en-us/services/azure-api-for-fhir/)
* [Microsoft Cloud for Healthcare](https://www.microsoft.com/en-us/industry/health/microsoft-cloud-for-healthcare)
* [Azure FHIR CDS Sync Agent deployment](./docs/deployment.md)
* [Azure API for FHIR Power Query connector for Power BI](https://docs.microsoft.com/en-us/power-query/connectors/fhir/fhir)
* [Azure API for FHIR Power Platform connector](https://docs.microsoft.com/en-us/connectors/fhirbase/)

