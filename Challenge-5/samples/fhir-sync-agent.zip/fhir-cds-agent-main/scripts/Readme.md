# FHIR-SyncAgent Getting started scripts Readme
Script purpose, order of execution and other steps necessary to get up and running with FHIR-SyncAgent

## Errata 
There is an open Issue with Azure KeyVault where it will not read ServiceBus Endpoints.  A fix is due in the September 2021 release, until then SB Connection strings are being written to both KeyVault and App Config file.  See the Reference section below for manual work-around steps. 

## Prerequisites 

These scripts will gather (and export) information necessary to the proper operation of the FHIR-SyncAgent and will store that information into the FHIR-Proxy Keyvault.  
 - Prerequisites:  Azure API for FHIR 
 - Prerequisites:  FHIR-Proxy must be installed along with a Keyvault 
 - Prerequisites:  The FHIR-Proxy createproxyserviceclient.bash script should be run (with keyvault use)

__Note__
A Keyvault is necessary for securing Service Client Credentials used with the FHIR Service and FHIR-Proxy.  Only 1 Keyvault should be used as this script scans the keyvault for FHIR Service and FHIR-Proxy values. If multiple Keyvaults have been used, please use the [backup and restore](https://docs.microsoft.com/en-us/azure/key-vault/general/backup?tabs=azure-cli) option to copy values to 1 keyvault.

__Note__ The FHIR-Sync Agent scripts are designed for and tested from the Azure Cloud Shell - Bash Shell environment.


## Step 1.  deploySyncAgent.bash
This is the main component deployment script for the Azure Components and Sync Agent code.  Note that retry logic is used to account for provisioning delays, i.e., networking provisioning is taking some extra time.  Default retry logic is 5 retries.   

Azure Components installed 
 - Function App (SyncAgent) with App Insights and Storage 
 - Function App Service plan 
 - Service Bus Namespace and Queue's
 - Service Bus Namespace Policies / Authroization rules

Note:  The FHIRBulkLoad Queue is Disabled by default (it should only be used in specific use cases)

Information needed by this script 
 - KeyVault Name installed with FHIR-Proxy 
 - Resource Group Location (recommended to install this in the same RG as FHIR-Proxy)
 - Resource Group Name (recommended to install this in the same RG as FHIR-Proxy)
 - Sync Agent Application Install Prefix (name is used to identify all sync agent components)
 

__FHIR-SyncAgent Application Configuration__ values loaded by this script 

Name                               | Value                      | Use             
-----------------------------------|----------------------------|---------------------------------
APPINSIGHTS_INSTRUMENTATIONKEY     | GUID                       | App Insights Key   
APPINSIGHTS_CONNECTION_STRING      | InstrumentationKey         | App Insights Connection 
AzureWebJobsStorage                | Endpoint                   | Function Storage Account
FUNCTIONS_EXTENSION_VERSION        | Function Version           | C# Code Extention (3.x) 
FUNCTIONS_WORKER_RUNTIME           | Function runtime           | C# Runtime (Windows) 
SA-FHIR-USEMSI                     | MSI Identity value         | True / False value 
SA-EMRAGENT-CONNECTION-TOPIC       | Static Queue name          | Queue / notification to EMR on FHIR update
SA-SERVICEBUSQUEUENAMECDSUPDATES   | Static Queue name          | Queue for CDS to FHIR updates
SA-SERVICEBUSQUEUENAMEFHIRBULK     | Static Queue name          | Queue for Bulk Loading - no order 
SA-SERVICEBUSQUEUENAMEFHIRUPDATES  | Static Queue name          | Queue for FHIR to CDS updates 
SA-SERVICEBUSNAMESPACECDSUPDATES   | SB Connection Endpoint     | Queue connection string
SA-SERVICEBUSNAMESPACEFHIRUPDATES  | SB Connection Endpoint     | Queue connection string 
SA-EMRAGENT-CONNECTION             | SB Connection Endpoint     | Queue connection string 


FHIR-SyncAgent Optional Application Settings - __NOT__ included in the setup scripts 

Name                                       | Value                      | Located 
-------------------------------------------|----------------------------|--------------------
AzureWebJobs.FHIRNDJsonFileLoader.Disabled | 1                          | Disables the bootstrap Loader  
SA-LOGREQRESP                              | True                       | Additional logging 


__FHIR-Proxy Application Configuration__ values loaded by this script 

Name                               | Value                      | Located              
-----------------------------------|----------------------------|--------------------
SA-FHIRMAPPEDRESOURCES             | Static Resource List       | Keyvault reference 
SA-SERVICEBUSQUEUENAMEFHIRBULK     | Static Queue name          | App Service Config 
SA-SERVICEBUSQUEUENAMEFHIRUPDATES  | Static Queue name          | App Service Config 
SA-SERVICEBUSNAMESPACEFHIRUPDATES  | SB Connection Endpoint     | Keyvault reference  
FP-POST-PROCESSOR-TYPES            | Proxy Module               | App Service Config          

Note:  The current iteration of the FP-POST-PROCESSOR-TYPES is __FHIRProxy.postprocessors.FHIRCDSSyncAgentPostProcess2__



## Step 2.  setupSyncAgent.bash
This script loads the Resources, ID's and Keys needed for FHIR-SyncAgent to Dataverse connectivity.  

This script should be run after 
- executing deploySyncAgent.bash 
- Changes are made to the ServiceBus Endpoints and / or Keys

__NOTE__ It is safe to re-run this script without issue. 

Information needed by this script
 - Resource Group and FHIR-Proxy App names
 - KeyVault Name installed with FHIR-Proxy
 - CDS Instance URL
 - CDS Tenant ID,
 - CDS Client ID,
 - CDS Client Secret

FHIR-SyncAgent Application Configuration values loaded by this script 

Name                               | Value                    | Located 
-----------------------------------|--------------------------|--------------------
SA-CDSAUDIENCE                     | Application URL          | Keyvault reference 
SA-CDSCLIENTID                     | Client ID                | Keyvault reference 
SA-CDSSECRET                       | Client Secret            | Keyvault reference 
SA-CDSTENANTID                     | Application Tenant ID    | Keyvault reference 
SA-FHIRMAPPEDRESOURCES             | Static Resource list     | Keyvault reference  


Dataverse Environment variables __EXPORTED__ by this script.  Admins need the following information to configure Dataverse Environment Variables via FHIR Sync Administration - Integration Settings 
- Service Bus URL
- Service Queue
- Service Bus Shared Access Policy
- Service Bus Shared Access Policy Key

__Note__ by default the following FHIR Resources mapped to the SyncAgent, if you wish to change them, simply edit the list in the Function App Config.  

Default Mapped Resources 
- Patient
- Appointment
- Encounter
- Observation
- Condition
- Procedure
- AllergyIntolerance
- MedicationRequest
- DiagnosticReport
- CarePlan
- Claim
- RelatedPerson

Edit the list in App Config by simply replacing the KeyVault Reference with a list of resources you wish to map.

![mapped](../docs/images/mapped-resources.png)

## Additional Scripts 
These are not necessary for FHIR-SyncAgent deployment & setup 

### controlSyncAgent.bash 
Control Sync Agent script will Enable / Disable the Sync Agent by adding / removing the Application Configuration setting __FP-POST-PROCESSOR-TYPES__ from the FHIR Proxy Application Configuration. 

This script can enable or disable the FHIR-SyncAgent 

FHIR-Proxy Application Configuration loaded by this script 

Name                               | Value                     | Located 
-----------------------------------|---------------------------|--------------------
FP-POST-PROCESSOR-TYPES            | Proxy Module              | App Service Config          

Note:  The current iteration of the FP-POST-PROCESSOR-TYPES is __FHIRProxy.postprocessors.FHIRCDSSyncAgentPostProcess2__


```bash
Usage: $0 -a <fhir-poxy appname> -g <resourceGroupName> -c <enable or disable>
```

 - enable adds the FP-POST-PROCESSOR-TYPES from the FHIR-Proxy Application Configuration and restarts Proxy 
 - disable removes the FP-POST-PROCESSOR-TYPES from the FHIR-Proxy Application Configuration and restarts Proxy 


## Reference 
Additional information to clarify FHIR-SyncAgent configuration settings 

### Auth values in KeyVault 
Multiple Auth vaules are stored in the Keyvault, part of this script's function will scan the Keyvault and build the values for configuration.  The following auth values are stored in the Keyvault 

Name                      | Definition                            | Set by 
--------------------------|---------------------------------------|--------------------
FS-CLIENT-ID              | FHIR Service Client ID                | Created manually 
FS-SECRET                 | FHIR Client ID Secret                 | Created manually  
FP-HOST                   | FHIR-Proxy host                       | FHIR-Proxy script   
FS-RESOURCE               | FHIR Service URL                      | FHIR-Proxy script  
FS-TENANT-NAME            | FHIR Service Tenant ID                | FHIR-Proxy script 
FS-URL                    | FHIR Service URL                      | FHIR-Proxy script 
FP-RBAC-CLIENT-ID         | FHIR Proxy Service Client for RBAC ID | FHIR-Proxy Script 
FP-RBAC-CLIENT-SECRET     | FHIR Proxy Service Client RBAC Secret | FHIR-Proxy Script 
FP-RBAC-NAME              | FHIR Proxy Service Client RBAC Host   | FHIR-Proxy Script 
FP-RBAC-TENANT-NAME       | FHIR Proxy Service Client RBAC Tenant | FHIR-Proxy Script 
FP-SC-CLIENT-ID           | FHIR Proxy Service Principal ID       | FHIR-Proxy CreateProxyServiceClient.bash
FP-SC-RESOURCE            | FHIR Proxy RBAC Client ID             | FHIR-Proxy CreateProxyServiceClient.bash
FP-SC-SECRET              | FHIR Proxy Service Principal Secret   | FHIR-Proxy CreateProxyServiceClient.bash
FP-SC-TENANT-NAME         | FHIR Proxy Service Principal Tenant   | FHIR-Proxy CreateProxyServiceClient.bash
FP-SC-URL                 | FHIR Proxy Service URL                | FHIR-Proxy CreateProxyServiceClient.bash
SA-CDSAUDIENCE            | CDS URL                               | FHIR-SyncAgent setupSyncAgent.bash 
SA-CDSCLIENTID            | CDS Client ID                         | FHIR-SyncAgent setupSyncAgent.bash
SA-CDSSECRET              | CDS Client Secret                     | FHIR-SyncAgent setupSyncAgent.bash
SA-CDSTENANTID            | CDS Tenant ID                         | FHIR-SyncAgent setupSyncAgent.bash



### KeyVault Issue with Service Bus manual work around 
Steps to manually set the FHIRUpdates queue name 

1) Go to the FHIR-SyncAgent App Config 

![sb](../docs/images/sb-config-1.png)

2) Change the WEBSITE_RUN_FROM_PACKAGE value to 0 to allow edits to the Function App 

![web](../docs/images/web-run-edit-1.png)

![web](../docs/images/web-run-edit-2.png)

![web](../docs/images/web-run-edit-3.png)

3) Locate the FHIRUpdates Function -> Integration -> Azure Service Bus (message) 

![function](../docs/images/function-1.png)

![function](../docs/images/function-2.png)

4) Change the Queue name to fhirupdates (click on Save when finished)

![function](../docs/images/function-3.png)

5) Validate the change by going to Function -> Code + Test -> Ensure queueName is set to fhirupdates 

![function](../docs/images/function-4.png)



### FAQ's
Frequently Asked Questions 

Q:  How do I know this is working 
A:  Patient Sample bundles and Postman 
