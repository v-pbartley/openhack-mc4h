#!/bin/bash
set -euo pipefail
IFS=$'\n\t'

# -e: immediately exit if any command has a non-zero exit status
# -o: prevents errors in a pipeline from being masked
# IFS new value is less likely to cause confusing bugs when looping arrays or arguments (e.g. $@)
#
# FHIR 2 CDS Sync Agent Setup --- Author Steve Ordahl Principal Architect Health Data Platform
#

# Notes from the SyncAgent code:
# // Service Bus settings defined in portal configuration
# // SB triggers use namespace, not the full connection string of the shared access policy
#
# Function             | Connection string variable        | queueName / aka trigger 
# ---------------------|-----------------------------------|--------------------------
# DVUpdates            | SA-SERVICEBUSNAMESPACECDSUPDATES  | %SA-SERVICEBUSQUEUENAMECDSUPDATES% 
# FHIRUpdates          | SA-SERVICEBUSNAMESPACEFHIRUPDATES | %SA-SERVICEBUSQUEUENAMEFHIRUPDATES%
# FHIRBulkLoad         | SA-SERVICEBUSNAMESPACEFHIRUPDATES | %SA-SERVICEBUSQUEUENAMEFHIRBULK%
# FHIRNDJsonFileLoader | SA-FHIRLOADERSTORAGECONNECTION    | ndjsonfiles/{name}


# SA-FHIRLOADERSTORAGECONNECTION
# SA-SERVICEBUSNAMESPACEFHIRUPDATES
# SA-SERVICEBUSQUEUENAMEFHIRUPDATES
# SA-SERVICEBUSNAMESPACEDVUPDATES
# SA-SERVICEBUSQUEUENAMEDVUPDATES
# SA-EMRAGENT-CONNECTION
# SA-EMRAGENT-CONNECTION-TOPIC
# FS-URL
# FS-TENANT-NAME
# FS-CLIENT-ID
# FS-SECRET
# FS-RESOURCE


#########################################
# HealthArchitecture Deployment Settings 
#########################################
declare TAG="HealthArchitectures: FHIR-SyncAgent"
declare functionSKU="B1"
declare functionWorkers="2"
declare storageSKU="Standard_LRS"
declare defserviceBusNamespaceSKU="Standard"
declare serviceBusNamespaceSKU=""
declare serviceBusQueueMaxSize="4096"


#########################################
# Sync Agent Variables 
#########################################
# Default name values
declare defSyncAgentInstallPrefix="syncagent"$RANDOM
declare deffhirSyncAgentAppName="sfsa"$RANDOM

# Fixed application values 
declare serviceBusQueueNameFhirUpdates="fhirupdates"
declare serviceBusQueueNameCdsUpdates="cdsupdates"
declare serviceBusQueueNameEMRUpdates="ehrupdatebroker"
declare serviceBusQueueNameFhirBulkLoad="fhirbulkloadunordered"

# Script variables to be set during deployment
declare nameSpaceConnectionString=""
declare cdsUpdatesConnectionString=""
declare fhirUpdatesConnectionString=""
declare emrUpdatesConnectionString=""
declare fhirBulkConnectionString=""
declare fhirSyncAgentAppName=""
declare fhirSyncAgentHost=""
declare fhirSyncAgentResourceId=""
declare fhirSyncAgentKey=""
declare serviceBusNameSpace=""

#########################################
# Proxy Variables 
#########################################
declare fpurl=""
declare fpappname=""

#########################################
# Keyvault variables 
#########################################
declare keyVaultAccountNameSuffix="kv"$RANDOM
declare kvname="";
declare kvexists=""

#########################################
# Script Control Variables
#########################################
# set to work around a KeyVault bug affecting Service Bus connections 
declare useAppConfig="yes"
declare useKeyVault="yes"

#########################################
# Common Variables
#########################################
declare defsubscriptionId=""
declare subscriptionId=""
declare resourceGroupName=""
declare resourceGroupLocation=""
declare storageAccountNameSuffix="store"
declare storageConnectionString=""
declare serviceplanSuffix="asp"
declare faname=""
declare fsurl=""
declare fsclientid=""
declare fssecret=""
declare fstenant=""
declare fsaud=""
declare fhirResourceId=""
declare syncAgentServicePrincipalId=""
declare distribution="../distribution/publish.zip"
declare deployprefix=""
declare defdeployprefix=""
declare stepresult=""
declare fahost=""
declare fakey=""
declare faresourceid=""
declare roleadmin="Administrator"
declare rolereader="Reader"
declare rolewriter="Writer"
declare rolepatient="Patient"
declare roleparticipant="Practitioner,RelatedPerson"
declare roleglobal="DataScientist"
declare spappid=""
declare spsecret=""
declare sptenant=""
declare spreplyurls=""
declare tokeniss=""
declare preprocessors=""
declare postprocessors=""
declare msi=""
declare count="0"



# Resources Required by this script 
# Need to add a test to see if these resource providers are enabled
# Service Bus 
# Function App 
# App Insights 

#########################################
#  Script Functions 
#########################################

function retry {
	# Retry logic  
    local n=1
    local max=5
    local delay=20
    while true; do
      "$@" && break || {
        if [[ $n -lt $max ]]; then
          ((n++))
          echo "Command failed. Retry Attempt $n/$max in $delay seconds:" >&2
          sleep $delay;
        else
          echo "The command has failed after $n attempts."
		  exit 1 ;
        fi
      }
    done
}

function kvuri {
	echo "@Microsoft.KeyVault(SecretUri=https://"$kvname".vault.azure.net/secrets/"$@"/)"
}


function intro {
	# Display the intro - give the user a chance to cancel 
	#
	echo " "
	echo "FHIR-SyncAgent Application installation script... "
	echo " - Prerequisite:  Azure API for FHIR must be installed"
	echo " - Prerequisite:  HealthArchitectures FHIR-Proxy must be installed with a KeyVault"
	echo " "
	echo "Note: You must have rights to able to provision Service Bus resources, Function Apps and App Insights at the Subscription level"
	echo " "
	read -p 'Press Enter to continue, or Ctrl+C to exit'
}


function result () {
    if [[ $1 = "ok" ]]; then
        echo -e "..................... [ \033[32m ok \033[37m ] \r" 
      else
        echo -e "..................... [ \033[31m failed \033[37m ] \r"
        exit 1
      fi
    echo -e "\033[37m \r"
    sleep 1
}

function healthCheck () {
	# Create a healthcheck varibales list to test the FHIR-SyncAgent deployment 
	#
	local functionname1=""
	local functionname2=""

	functionname1=$(echo $1 | awk -F= '{ print $1 }')
	functionname2=$(echo $1 | awk -F= '{ print $2 }')

	if [[ $count -eq 0 ]]; then
		echo "# FHIR Sync Agent Healthcheck variables" > ./healthcheck.txt
		echo "declare $functionname1=\"$functionname2\"" >> ./healthcheck.txt ;
	else 
		echo "declare $functionname1=\"$functionname2\"" >> ./healthcheck.txt ;
	fi 
	((count++))
}

function appState () {
	az functionapp show --name $1 --resource-group $2 | grep state
	sleep 2
}


usage() { echo "Usage: $0 -i <subscriptionId> -g <resourceGroupName> -l <resourceGroupLocation> -p <prefix>" 1>&2; exit 1; }



#########################################
#  Script Main Body (start script execution here)
#########################################
#
# Initialize parameters specified from command line
# 
while getopts ":i:g:l:p" arg; do
	case "${arg}" in
		p)
			deployprefix=${OPTARG:0:14}
			deployprefix=${deployprefix,,}
			deployprefix=${deployprefix//[^[:alnum:]]/}
			;;
		i)
			subscriptionId=${OPTARG}
			;;
		g)
			resourceGroupName=${OPTARG}
			;;
		l)
			resourceGroupLocation=${OPTARG}
			;;
		esac
done
shift $((OPTIND-1))
echo "Executing "$0"..."
echo "Checking Azure Authentication..."

# login to azure using your credentials
#
az account show 1> /dev/null

if [ $? != 0 ];
then
	az login
fi

# set default subscription information
#
defsubscriptionId=$(az account show --query "id" --out json | sed 's/"//g') 


# Call the Introduction function 
#
intro

#Prompt for common parameters if some required parameters are missing
#
echo " "
echo "Collecting Azure Parameters (unless supplied on the command line) "

if [[ -z "$subscriptionId" ]]; then
	echo "Enter your subscription ID <press Enter to accept default> ["$defsubscriptionId"]: "
	read subscriptionId
	if [ -z "$subscriptionId" ] ; then
		subscriptionId=$defsubscriptionId
	fi
	[[ "${subscriptionId:?}" ]]
fi

if [[ -z "$resourceGroupName" ]]; then
	echo "This script will look for an existing resource group, otherwise a new one will be created "
	echo "You can create new resource groups with the CLI using: az group create "
    echo " "
	echo "Enter a resource group name []: "
	read resourceGroupName
	[[ "${resourceGroupName:?}" ]]
fi

if [[ -z "$resourceGroupLocation" ]]; then
	echo "If creating a *new* resource group, you need to set a location "
	echo "You can lookup locations with the CLI using: az account list-locations "
	echo " "
	echo "Enter resource group location []: "
	read resourceGroupLocation
	[[ "${resourceGroupLocation:?}" ]]
fi

# Ensure there are subscriptionId and resourcegroup names 
#
if [ -z "$subscriptionId" ] || [ -z "$resourceGroupName" ]; then
	echo "Either one of subscriptionId, resourceGroupName is empty, exiting..."
	exit 1
fi


# Prompt for script parameters if some required parameters are missing
#
echo " "
echo "Collecting Script Parameters..."

# Set Default Deployment Prefix
#
defdeployprefix=${defSyncAgentInstallPrefix:0:14}
defdeployprefix=${defdeployprefix//[^[:alnum:]]/}
defdeployprefix=${defdeployprefix,,}

# Prompt for deployment prefix, otherwise use the defaulf 
#
if [[ -z "$deployprefix" ]]; then
	echo "Enter your application install prefix <press Enter to accept default> ["$defdeployprefix"]:"
	read deployprefix
	if [ -z "$deployprefix" ] ; then
		deployprefix=$defdeployprefix
	fi
	deployprefix=${deployprefix:0:14}
	deployprefix=${deployprefix//[^[:alnum:]]/}
    deployprefix=${deployprefix,,}
	[[ "${deployprefix:?}" ]]
fi

# Prompt for remaining details 
#

echo " "
echo "Enter an existing keyvault name to retrieve FHIR-Proxy configuration []:"
	read kvname
	if [ -z "$kvname" ] ; then
		kvname=$kvname
	fi
	[[ "${kvname:?}" ]]

# Check KV exists and load information 
#
echo " "
echo "   Checking for keyvault "$kvname"..."
kvexists=$(az keyvault list --query "[?name == '$kvname'].name" --out tsv)
if [[ -n "$kvexists" ]]; then
	set +e
	echo "   ............. "$kvname "found"
	echo " "
	echo "   Checking ["$kvname"] for FHIR-Proxy configuration..."
	fphost=$(az keyvault secret show --vault-name $kvname --name FP-HOST --query "value" --out tsv)
	if [ -n "$fphost" ]; then
		echo "   .......... found FP-HOST: ["$fphost"]"
        fpappname=$(az keyvault secret show --vault-name $kvname --name FP-HOST --query "value" --out tsv | awk -F. '{print $1}') ;
	else	
		echo "   .....unable to read FP-HOST from ["$kvname"]" 
		result "fail";
	fi 
else
	echo "Failed to find KeyVault..." $kvname  ;
	result "fail";
fi

# IF KV exists (see above), then pull out the FHIR Service Identity  
#
echo " "
if [[ -n "$kvexists" ]]; then
	set +e
	echo "   Checking ["$kvname"] for FHIR Service configuration..."
	fsurl=$(az keyvault secret show --vault-name $kvname --name FS-URL --query "value" --out tsv)
	if [ -n "$fsurl" ]; then
		echo "   ......... found FHIR Service ["$fsurl"]"
        fhirResourceId=$(az keyvault secret show --vault-name $kvname --name FS-URL --query "value" --out tsv | awk -F. '{print $1}' | sed -e 's/https\:\/\///g') ;
		echo "   ......... FHIR Resource ID set to: ["$fhirResourceId"]"
	else	
		echo "   ......... unable to read FS-URL from " $kvname 
		result "fail";
	fi 
else
	echo "Failed to find KeyVault..." $kvname ;
	result "fail";
fi


# Prompt for FHIR-SyncAgent Information  
#
echo " "
echo "Enter the FHIR-SyncAgent app name <press Enter to accept default> ["$deffhirSyncAgentAppName"]:"
	read fhirSyncAgentAppName
	if [ -z "$fhirSyncAgentAppName" ] ; then
		fhirSyncAgentAppName=$deffhirSyncAgentAppName
	fi
	[[ "${fhirSyncAgentAppName:?}" ]]


# Prompt for Service Bus SKU
echo " "
echo "Enter the Service Bus SKU to be used, Premium or Standard <press Enter to accept default> ["$defserviceBusNamespaceSKU"]:"
	read serviceBusNamespaceSKU
	if [ -z "$serviceBusNamespaceSKU" ] ; then
		serviceBusNamespaceSKU=$defserviceBusNamespaceSKU
	fi
	[[ "${serviceBusNamespaceSKU:?}" ]]


# set the default subscription id
#
echo "Setting default subscription....."
az account set --subscription $subscriptionId

set +e

# Check for existing RG
#
if [ $(az group exists --name $resourceGroupName) = false ]; then
	echo "Resource group with name" $resourceGroupName "could not be found.   Exiting..."
	usage ;
else
	echo "Using $resourceGroupName as resource group..."
fi

#
echo "Ready to start deployment of ["$fhirSyncAgentAppName"] with the following values:"
echo "Subscription ID: " $subscriptionId
echo "Resource Group Name: " $resourceGroupName 
echo "Resource Group Location: " $resourceGroupLocation 
echo "Application Prefix: " $deployprefix
echo " FHIR-Proxy App Name: "$fpappname 
echo " FHIR Service Name: "$fhirResourceId
echo "Service Bus SKU:  "$serviceBusNamespaceSKU
echo " "
echo "Please validate the settings above and... "
read -p 'Press Enter to continue, or Ctrl+C to exit'


#############################################
#  Start FHIR-Proxy Configuration / Updates 
#############################################
#
echo " "
echo "Updating Secure FHIR-Proxy [$fpappname] Application Configuration to enable FHIR-SyncAgent..."
(
	stepresult=$(az functionapp config appsettings set --name $fpappname --resource-group $resourceGroupName --settings SA-FHIRMAPPEDRESOURCES=$(kvuri SA-FHIRMAPPEDRESOURCES) SA-SERVICEBUSNAMESPACEFHIRUPDATES=$(kvuri SA-SERVICEBUSNAMESPACEFHIRUPDATES) SA-SERVICEBUSNAMESPACECDSUPDATES=$(kvuri SA-SERVICEBUSNAMESPACECDSUPDATES) SA-SERVICEBUSQUEUENAMEFHIRBULK=$serviceBusQueueNameFhirBulkLoad SA-SERVICEBUSQUEUENAMEFHIRUPDATES=$serviceBusQueueNameFhirUpdates SA-SERVICEBUSQUEUENAMECDSUPDATES=$serviceBusQueueNameCdsUpdates FP-POST-PROCESSOR-TYPES=FHIRProxy.postprocessors.FHIRCDSSyncAgentPostProcess2 ) 

)

if [ $?  != 0 ];
 then
	echo "Failed to update FHIR-Proxy, please check app config for write ability..."
fi

sleep 5

#########################################
#  Start SyncAgent Deployment
#########################################
#
echo " "
echo "Starting Secure FHIR-SyncAgent Function Application ["$fhirSyncAgentAppName"] deployment..."
(
	# Create Storage Account
	echo "Creating Secure Function App Storage Account ["$deployprefix$storageAccountNameSuffix"]..."
	stepresult=$(az storage account create --name $deployprefix$storageAccountNameSuffix --resource-group $resourceGroupName --location  $resourceGroupLocation --sku $storageSKU --encryption-services blob --tags $TAG)

	echo "Retrieving Storage Account Connection String... "
	storageConnectionString=$(az storage account show-connection-string -g $resourceGroupName -n $deployprefix$storageAccountNameSuffix --query "connectionString" --out tsv)
	
	# Creating NDJSON Container - needed to fulfill the use case of FHIR Server Export to bootstrap the SyncAgent 
	echo "Creating ndjson container in the SyncAgent Storage Account..."
	echo "...note this is for small scale testing, not production capacity - for production, use the FHIR-Loader"
	stepresult=$(az storage container create -n ndjson --connection-string $storageConnectionString)

	stepresult=$(az keyvault secret set --vault-name $kvname --name "SA-FHIRLOADERSTORAGECONNECTION" --value $storageConnectionString)

	# Create App Service Plan
	echo "Creating Secure FHIR-SyncAgent Function App Serviceplan ["$deployprefix$serviceplanSuffix"]..."
	stepresult=$(az appservice plan create -g  $resourceGroupName -n $deployprefix$serviceplanSuffix --number-of-workers $functionWorkers --sku $functionSKU --tags $TAG)
 

	# Create Function app
	echo "Creating Secure FHIR-SyncAgent Function App ["$fhirSyncAgentAppName"]..."
	fhirSyncAgentHost=$(az functionapp create --name $fhirSyncAgentAppName --storage-account $deployprefix$storageAccountNameSuffix  --plan $deployprefix$serviceplanSuffix --resource-group $resourceGroupName --runtime dotnet --os-type Windows --functions-version 3 --tags $TAG --query defaultHostName --output tsv)

	echo "FHIR-SyncAgent Function App Host name = "$fhirSyncAgentHost

	# Test Function app status
	echo "FHIR-SyncAgent ["$fhirSyncAgentAppName"] state..."
	appState $fhirSyncAgentAppName $resourceGroupName


	# Setup Auth  
	echo "Creating MSI for FHIR-SyncAgent Function App ["$fhirSyncAgentAppName"] "
	msi=$(az functionapp identity assign -g $resourceGroupName -n $fhirSyncAgentAppName --query "principalId" --out tsv)

    echo "Setting Application Config MSI Setting"
    stepresult=$(az functionapp config appsettings set --name $fhirSyncAgentAppName --resource-group $resourceGroupName --settings SA-FHIR-USEMSI=True)

	# Setup KeyVault access 
	echo "Setting KeyVault Policy to allow KeyVault Secret access for FHIR-SyncAgent App..."
	stepresult=$(az keyvault set-policy -n $kvname --secret-permissions list get set --object-id $msi)


	# Apply App Settings
	echo "Applying FHIR-SyncAgent Application Configuration settings for ["$fhirSyncAgentAppName"]..."
	stepresult=$(az functionapp config appsettings set --name $fhirSyncAgentAppName --resource-group $resourceGroupName --settings FS-URL=$(kvuri FS-URL) FS-TENANT-NAME=$(kvuri FS-TENANT-NAME) FS-CLIENT-ID=$(kvuri FS-CLIENT-ID) FS-SECRET=$(kvuri FS-SECRET) FS-RESOURCE=$(kvuri FS-RESOURCE) SA-CDSAUDIENCE=$(kvuri SA-CDSAUDIENCE) SA-CDSCLIENTID=$(kvuri SA-CDSCLIENTID) SA-CDSSECRET=$(kvuri SA-CDSSECRET) SA-CDSTENANTID=$(kvuri SA-CDSTENANTID) SA-EMRAGENT-CONNECTION=$(kvuri SA-EMRAGENT-CONNECTION) SA-FHIR-USEMSI=TRUE SA-FHIRLOADERSTORAGECONNECTION=$(kvuri SA-FHIRLOADERSTORAGECONNECTION) SA-FHIRMAPPEDRESOURCES=$(kvuri SA-FHIRMAPPEDRESOURCES) SA-SERVICEBUSNAMESPACECDSUPDATES=$(kvuri SA-SERVICEBUSNAMESPACECDSUPDATES) SA-SERVICEBUSNAMESPACEFHIRUPDATES=$(kvuri SA-SERVICEBUSNAMESPACEFHIRUPDATES) SA-SERVICEBUSQUEUENAMECDSUPDATES=$serviceBusQueueNameCdsUpdates SA-SERVICEBUSQUEUENAMEFHIRBULK=$serviceBusQueueNameFhirBulkLoad SA-SERVICEBUSQUEUENAMEFHIRUPDATES=$serviceBusQueueNameFhirUpdates SA-EMRAGENT-CONNECTION-TOPIC=$serviceBusQueueNameEMRUpdates)

	# Obtain FHIR-SyncAgent Key 
	echo "Retrieving FHIR-SyncAgent Host Key...  this step will automatically retry if it fails"
	fhirSyncAgentResourceId="/subscriptions/"$subscriptionId"/resourceGroups/"$resourceGroupName"/providers/Microsoft.Web/sites/"$fhirSyncAgentAppName
	
	#fhirSyncAgentKey=$(retry az rest --method post --uri "https://management.azure.com"$fhirSyncAgentResourceId"/host/default/listKeys?api-version=2018-02-01" --query "functionKeys.default" --output tsv)

	# Testing new API - old one is not responding 
	fhirSyncAgentKey=$(retry az rest --method post --uri "https://management.azure.com"$fhirSyncAgentResourceId"/host/default/listKeys?api-version=2021-02-01" --query "functionKeys.default" --output tsv)

	if [ $?  != 0 ]; then
		echo "Failed to retrieve FHIR-SyncAgent Host Key, please check app config for write ability..."
		exit 1 ;
	fi

	# Deploy the function code from the local folder
	echo "Deploying FHIR-SyncAgent App code from local source to ["$fhirSyncAgentAppName"]... this step will automatically retry if it fails"
	stepresult=$(retry az functionapp deployment source config-zip --resource-group $resourceGroupName --name $fhirSyncAgentAppName --src $distribution )

	# Start the app 
	# Ref: https://docs.microsoft.com/en-us/azure/azure-functions/run-functions-from-deployment-package
	echo "...NOTE:  After deployment, the FHIR-SyncAgent App ["$fhirSyncAgentAppName"] will restart automatically"
	
	# Uncomment to for an app restart 
	#stepresult=$(retry az functionapp restart --name $fhirSyncAgentAppName --resource-group $resourceGroupName --subscription $subscriptionId)

	sleep 5 

	# Test Function app status
	echo "FHIR-SyncAgent ["$fhirSyncAgentAppName"] state..."
	appState $fhirSyncAgentAppName $resourceGroupName	

	sleep 5

	# Setup RBAC access to FHIR Service 
	echo "Setting ["$fhirSyncAgentAppName"] MSI RBAC Access to FHIR Service ["$fhirResourceId"]..."
	syncAgentServicePrincipalId=$(az resource list -n $fhirSyncAgentAppName --query [*].identity.principalId --out tsv)
	stepresult=$(az role assignment create --assignee $syncAgentServicePrincipalId --role 'FHIR Data Contributor' --scope /subscriptions/$subscriptionId/resourceGroups/$resourceGroupName/providers/Microsoft.HealthcareApis/services/$fhirResourceId)


	echo " "
	echo "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -"
	echo " Secure FHIR-SyncAgent Function has successfully been deployed to group ["$resourceGroupName"] on "$(date)
	echo " Secure FHIR-SyncAgent Function App URL is: [https://"$fhirSyncAgentHost"]"
	echo " Secure app configuration settings are stored securely in KeyVault: ["$kvname"]"
	echo "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -"
	echo " "
)
	
if [ $?  != 0 ];
 then
	echo "FHIR-SyncAgent Function Application deployment had errors. Consider deleting the resources and trying again..."
fi

sleep 5

#########################################
#  Start Deployment
#########################################
#
echo " "
echo "Starting FHIR-SyncAgent Service Bus Namespace and Queue deployment..."
(
    # Create Service Bus Namespace 
	# Ref:  https://docs.microsoft.com/en-us/azure/service-bus-messaging/service-bus-authentication-and-authorization#shared-access-signature
	#

	if [[ "$serviceBusNamespaceSKU" == "Standard" ]]; then
	    serviceBusNameSpace="${deployprefix}sbns"
		echo "Creating Standard Service Bus Namespace ["$serviceBusNameSpace"]  This operation can take a while to complete.."
		stepresult=$(az servicebus namespace create --resource-group $resourceGroupName --name $serviceBusNameSpace --location $resourceGroupLocation --sku $serviceBusNamespaceSKU --tags $TAG)
		declare serviceBusQueueMaxSize="4096"
	fi 

	if [[ "$serviceBusNamespaceSKU" == "Premium" ]]; then
	    serviceBusNameSpace="${deployprefix}sbns"
		echo "Creating Premium Service Bus Namespace ["$serviceBusNameSpace"]  This operation can take a while to complete.."
		stepresult=$(az servicebus namespace create --resource-group $resourceGroupName --name $serviceBusNameSpace --location $resourceGroupLocation --sku $serviceBusNamespaceSKU --capacity 8 --tags $TAG)
		declare serviceBusQueueMaxSize="81920"
	fi

	# sleep needed for sb deployment to complete 
	sleep 10

	# Note that we do not need to create the RootManageSharedAccessKey, as it is created by default when the namespace is created, therefore we create an app specific Auth rule without Management access 
    
	# Creating a SyncAgent Auth Rule with Listen and Send only
	echo "Creating ["$serviceBusNameSpace"] SyncAgentSharedAccessKey Authorization rule..."
    stepresult=$(az servicebus namespace authorization-rule create --resource-group $resourceGroupName --namespace-name $serviceBusNameSpace --name SyncAgentSharedAccessKey --rights Send Listen) 

	# Creating the primary queue connection string using the SyncAgentSharedAccessKey Auth Rule 
	echo "Creating ["$serviceBusNameSpace"] SyncAgentSharedAccessKey connection string..."
	nameSpaceConnectionString=$(az servicebus namespace authorization-rule keys list --resource-group $resourceGroupName --namespace-name $serviceBusNameSpace --name SyncAgentSharedAccessKey --query primaryConnectionString --output tsv)

	echo " "

	# ----------------------------------------------
	# SB triggers use namespace, not the full connection string of the shared access policy
	# ----------------------------------------------

	####### 
    # Create Service Bus ORDERED QUEUES
	#
	echo "Creating ["$serviceBusNameSpace"] Queue's..."
	echo " "

	####
	# Create Service Bus Queue dvupdates / aka cdsupdates 
	echo "Creating "$serviceBusNameSpace" Queue ["$serviceBusQueueNameCdsUpdates"]..."
    stepresult=$(az servicebus queue create --resource-group $resourceGroupName --namespace-name $serviceBusNameSpace --name $serviceBusQueueNameCdsUpdates --max-size $serviceBusQueueMaxSize --enable-duplicate-detection true --enable-session true --enable-partitioning true --duplicate-detection-history-time-window PT10M --max-delivery-count 10 --status Active)
	
	# sleep needed for sb deployment to complete 
	sleep 10
		
	# Storing the Namespace connection string in KeyVault	
	if [[ "$useKeyVault" == "yes" ]]; then
	    echo "Storing "$serviceBusQueueNameCdsUpdates" connection string in KeyVault "$kvname
    	stepresult=$(az keyvault secret set --vault-name $kvname --name "SA-SERVICEBUSNAMESPACECDSUPDATES" --value $nameSpaceConnectionString)
	fi

	# storing the Namespace connection string in App Config to use without Keyvault 
	if [[ "$useAppConfig" == "yes" ]]; then
		echo "Storing "$serviceBusQueueNameFhirUpdates" connection string in ["$fhirSyncAgentAppName"] config"
		stepresult=$(az functionapp config appsettings set --name $fhirSyncAgentAppName --resource-group $resourceGroupName --settings SA-SERVICEBUSNAMESPACECDSUPDATES=$nameSpaceConnectionString)
	fi

	echo " "

	# ----------------------------------------------

    ####
	# Create Service Bus Queue fhirupdates
	echo "Creating "$serviceBusNameSpace" Queue ["$serviceBusQueueNameFhirUpdates"]..."	
	stepresult=$(az servicebus queue create --resource-group $resourceGroupName --namespace-name $serviceBusNameSpace --name $serviceBusQueueNameFhirUpdates --max-size $serviceBusQueueMaxSize --enable-duplicate-detection true --enable-session true --enable-partitioning true --duplicate-detection-history-time-window PT10M --max-delivery-count 10 --status Active )
	
	# sleep needed for sb deployment to complete 
	sleep 10
	
	# Storing the Namespace connection string in KeyVault	
	if [[ "$useKeyVault" == "yes" ]]; then
		echo "Storing "$serviceBusQueueNameFhirUpdates" connection string in KeyVault "$kvname
    	stepresult=$(az keyvault secret set --vault-name $kvname --name "SA-SERVICEBUSNAMESPACEFHIRUPDATES" --value $nameSpaceConnectionString)
	fi

	# storing the Namespace connection string in App Config to use without Keyvault 
	if [[ "$useAppConfig" == "yes" ]]; then
		echo "Storing "$serviceBusQueueNameFhirUpdates" connection string in ["$fhirSyncAgentAppName"] config"
		stepresult=$(az functionapp config appsettings set --name $fhirSyncAgentAppName --resource-group $resourceGroupName --settings SA-SERVICEBUSNAMESPACEFHIRUPDATES=$nameSpaceConnectionString)
	fi

	echo " "
	# --------------------------------------------------

    ####
	# Create Service Bus Queue ehrupdatebroker
	echo "Creating "$serviceBusNameSpace" Queue ["$serviceBusQueueNameEMRUpdates"]..."
	stepresult=$(az servicebus queue create --resource-group $resourceGroupName --namespace-name $serviceBusNameSpace --name $serviceBusQueueNameEMRUpdates --max-size $serviceBusQueueMaxSize --enable-duplicate-detection true --enable-session true --enable-partitioning true --duplicate-detection-history-time-window PT10M --max-delivery-count 10 --status Active )
		
	# sleep needed for sb deployment to complete 
	sleep 10

	# Storing the Namespace connection string in KeyVault	
	if [[ "$useKeyVault" == "yes" ]]; then
		echo "Storing "$serviceBusQueueNameEMRUpdates" connection string in KeyVault "$kvname
    	stepresult=$(az keyvault secret set --vault-name $kvname --name "SA-EMRAGENT-CONNECTION" --value $nameSpaceConnectionString)
	fi

	# storing the Namespace connection string in App Config to use without Keyvault 
	if [[ "$useAppConfig" == "yes" ]]; then
		echo "Storing "$serviceBusQueueNameFhirUpdates" connection string in ["$fhirSyncAgentAppName"] config"
		stepresult=$(az functionapp config appsettings set --name $fhirSyncAgentAppName --resource-group $resourceGroupName --settings SA-EMRAGENT-CONNECTION=$nameSpaceConnectionString)
	fi

	echo " "

	# --------------------------------------------------

    ###
    # Create Service Bus Queue fhirbulkimport (un-ordered) 
	echo "Creating "$serviceBusNameSpace" Queue ["$serviceBusQueueNameFhirBulkLoad"]..."
    stepresult=$(az servicebus queue create --resource-group $resourceGroupName --namespace-name $serviceBusNameSpace --name $serviceBusQueueNameFhirBulkLoad --max-size $serviceBusQueueMaxSize --enable-duplicate-detection false --enable-session false --enable-dead-lettering-on-message-expiration false --default-message-time-to-live P14D  --lock-duration PT30S --enable-duplicate-detection false --max-delivery-count 10 --status Disabled )

	# sleep needed for sb deployment to complete 
	sleep 10
	
		# Storing the Namespace connection string in KeyVault	
	if [[ "$useKeyVault" == "yes" ]]; then
		echo "Storing "$serviceBusQueueNameFhirBulkLoad" connection string in KeyVault "$kvname
    	stepresult=$(az keyvault secret set --vault-name $kvname --name "SA-SERVICEBUSNAMESPACEFHIRBULKLOAD" --value $nameSpaceConnectionString)
	fi 

	if [[ "$useAppConfig" == "yes" ]]; then
		echo "Storing "$serviceBusQueueNameFhirBulkLoad" connection string in ["$fhirSyncAgentAppName"] config"
		stepresult=$(az functionapp config appsettings set --name $fhirSyncAgentAppName --resource-group $resourceGroupName --settings SA-SERVICEBUSNAMESPACEFHIRBULKLOAD=$nameSpaceConnectionString)
	fi 

    	
	echo " "
	echo "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -"
	echo " FHIR-SyncAgent Service Bus Namespace and Queue's have been deployed to group ["$resourceGroupName"] on "$(date)
	echo " Secure Service Bus Connection settings are stored in KeyVault: ["$kvname"]"
	echo " Service Bus Queue Names are stored in the ["$fhirSyncAgentAppName"] Application Configuration "
	echo "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -"
	echo " "

	echo "Finishing Deployment and Configuration..."

	if [[ "$useAppConfig" == "yes" ]]; then
		echo "Storing Connection Strings in Secure FHIR-Proxy ["$fpappname"] Application Configuration..."
		stepresult=$(az functionapp config appsettings set --name $fpappname --resource-group $resourceGroupName --settings SA-FHIRMAPPEDRESOURCES=$(kvuri SA-FHIRMAPPEDRESOURCES) SA-SERVICEBUSNAMESPACEFHIRUPDATES=$nameSpaceConnectionString SA-SERVICEBUSNAMESPACECDSUPDATES=$nameSpaceConnectionString SA-SERVICEBUSQUEUENAMEFHIRBULK=$serviceBusQueueNameFhirBulkLoad SA-SERVICEBUSQUEUENAMEFHIRUPDATES=$serviceBusQueueNameFhirUpdates SA-SERVICEBUSQUEUENAMECDSUPDATES=$serviceBusQueueNameCdsUpdates ) 
	fi

	echo "Setting FHIR-SyncAgent Application Config option to Read Only"
	stepresult=$(az functionapp config appsettings set --name $fhirSyncAgentAppName --resource-group $resourceGroupName --settings WEBSITE_RUN_FROM_PACKAGE=1 )

	echo " "
	echo "************************************************************************************************************"
	echo " FHIR-SyncAgent and Service Bus Installation completed without errors "
	echo " Run the [SetupSyncAgent.bash] script next to gather and export the new ServiceBus Key needed in Dynamics"
	echo "************************************************************************************************************"
	echo " "


)

if [ $?  != 0 ];
 then
	echo "FHIR-SyncAgent Application final configuration had errors. Consider deleting the resources created and trying again..."
fi
	

