#!/bin/bash
set -euo pipefail
IFS=$'\n\t'

# -e: immediately exit if any command has a non-zero exit status
# -o: prevents errors in a pipeline from being masked
# IFS new value is less likely to cause confusing bugs when looping arrays or arguments (e.g. $@)
#
# FHIR 2 CDS Sync Agent Setup --- Author Steve Ordahl Principal Architect Health Data Platform
#

# Notes from the SyncAgent code:
# // Service Bus settings defined in portal configuration
# // SB triggers use namespace, not the full connection string of the shared access policy
#
# Function             | Connection string variable        | queueName / aka trigger 
# ---------------------|-----------------------------------|--------------------------
# DVUpdates            | SA-SERVICEBUSNAMESPACECDSUPDATES  | %SA-SERVICEBUSQUEUENAMECDSUPDATES% 
# FHIRUpdates          | SA-SERVICEBUSNAMESPACEFHIRUPDATES | %SA-SERVICEBUSQUEUENAMEFHIRUPDATES%
# FHIRBulkLoad         | SA-SERVICEBUSNAMESPACEFHIRUPDATES | %SA-SERVICEBUSQUEUENAMEFHIRBULK%
# FHIRNDJsonFileLoader | SA-FHIRLOADERSTORAGECONNECTION    | ndjsonfiles/{name}


# SA-FHIRLOADERSTORAGECONNECTION
# SA-SERVICEBUSNAMESPACEFHIRUPDATES
# SA-SERVICEBUSQUEUENAMEFHIRUPDATES
# SA-SERVICEBUSNAMESPACEDVUPDATES
# SA-SERVICEBUSQUEUENAMEDVUPDATES
# SA-EMRAGENT-CONNECTION
# SA-EMRAGENT-CONNECTION-TOPIC
# FS-URL
# FS-TENANT-NAME
# FS-CLIENT-ID
# FS-SECRET
# FS-RESOURCE


#########################################
# HealthArchitecture Deployment Settings 
#########################################
declare TAG="HealthArchitectures: FHIR-SyncAgent"
declare functionSKU="B1"
declare functionWorkers="2"
declare storageSKU="Standard_LRS"
declare serviceBusNamespaceSKU="Standard"
declare serviceBusQueueMaxSize="4096"


#########################################
# Sync Agent Variables 
#########################################
# Default name values
declare defAppInstallPrefix="syncagent"$RANDOM
declare deffhirSyncAgentAppName="sfsa"$RANDOM

# Fixed application values 
declare serviceBusQueueNameFhirUpdates="fhirupdates"
declare serviceBusQueueNameCdsUpdates="cdsupdates"
declare serviceBusQueueNameEMRUpdates="ehrupdatebroker"
declare serviceBusQueueNameFhirBulkLoad="fhirbulkloadunordered"

# Script variables to be set during deployment
declare nameSpaceConnectionString=""
declare cdsUpdatesConnectionString=""
declare fhirUpdatesConnectionString=""
declare emrUpdatesConnectionString=""
declare fhirBulkConnectionString=""
declare fhirSyncAgentAppName=""
declare fhirSyncAgentHost=""
declare fhirSyncAgentResourceId=""
declare fhirSyncAgentKey=""
declare serviceBusNameSpace=""

#########################################
# Proxy Variables 
#########################################
declare fpurl=""
declare fpappname=""

#########################################
# Keyvault variables 
#########################################
declare keyVaultAccountNameSuffix="kv"$RANDOM
declare kvname="";
declare kvexists=""

#########################################
# Script Control Variables
#########################################
# set to work around a KeyVault bug affecting Service Bus connections 
declare useAppConfig="yes"
declare useKeyVault="yes"

#########################################
# Common Variables
#########################################
declare defsubscriptionId=""
declare subscriptionId=""
declare resourceGroupName=""
declare resourceGroupLocation=""
declare storageAccountNameSuffix="store"
declare storageConnectionString=""
declare serviceplanSuffix="asp"
declare faname=""
declare fsurl=""
declare fsclientid=""
declare fssecret=""
declare fstenant=""
declare fsaud=""
declare fhirResourceId=""
declare syncAgentServicePrincipalId=""
declare distribution="../distribution/publish.zip"
declare deployprefix=""
declare defdeployprefix=""
declare stepresult=""
declare fahost=""
declare fakey=""
declare faresourceid=""
declare roleadmin="Administrator"
declare rolereader="Reader"
declare rolewriter="Writer"
declare rolepatient="Patient"
declare roleparticipant="Practitioner,RelatedPerson"
declare roleglobal="DataScientist"
declare spappid=""
declare spsecret=""
declare sptenant=""
declare spreplyurls=""
declare tokeniss=""
declare preprocessors=""
declare postprocessors=""
declare msi=""
declare count="0"



# Resources Required by this script 
# Need to add a test to see if these resource providers are enabled
# Service Bus 
# Function App 
# App Insights 

#########################################
#  Script Functions 
#########################################
