#!/bin/bash
set -euo pipefail
IFS=$'\n\t'

# -e: immediately exit if any command has a non-zero exit status
# -o: prevents errors in a pipeline from being masked
# IFS new value is less likely to cause confusing bugs when looping arrays or arguments (e.g. $@)
#
# FHIR 2 CDS Sync Agent Setup --- Author Steve Ordahl Principal Architect Health Data Platform
#

# Script will setup initial Keyvault settings for CDS Sync Agent.
#
# SA-FHIRMAPPEDRESOURCES - static resources to be mapped to the FHIR server
# SA-CDSAUDIENCE - Obtain from Dataverse Environment variable setup / config 
# SA-dvTenantId - Obtain from Dataverse Environment variable setup / config 
# SA-dvClientId - Obtain from Dataverse Environment variable setup / config 
# SA-CDSSECRET - Obtain from Dataverse Environment variable setup / config 


# Keyvault settings
#
# Default Resources to be mapped into FHIR-SyncAgent 
declare fhirMappedResources="Patient,Appointment,Encounter,Observation,Condition,Procedure,Device,AllergyIntolerance,MedicationRequest,DiagnosticReport,CarePlan,Claim,RelatedPerson,Organization,Location,Medication,Slot,Schedule,CareTeam,Practitioner,Participant"
declare fhirMappedResourcesArray=(${fhirMappedResources//,/ })

# Default Resources to be mapped into Dataverse Environment variables 
# 
declare cdsUpdateConnectionString=""
declare cdsServiceBusUrl=""
declare cdsServiceQueue="cdsupdates"
declare serviceBusCdsUpdates="cdsupdates"
declare cdsServiceBusSharedAccessPolicy=""
declare cdsServiceBusSharedAccessPolicyKey=""



# Script variables 
#
declare defaultSubscriptionID=""
declare resourceGroupName=""
declare keyVaultName=""
declare keyVaultExists=""
declare fhirProxyHostName=""
declare fhirProxyAppName=""
declare dvInstanceUrl=""
declare dvTenantId=""
declare dvClientId=""
declare dvClientSecret=""
declare cdsAudience=""
declare cdsSubscriptionId=""
declare dvInstanceUrl=""
declare dvTenantId=""
declare dvClientId=""
declare dvClientSecret=""
declare dvAudience=""
declare dvSubscriptionId=""


#########################################
#  Script Functions 
#########################################

function kvuri {
	echo "@Microsoft.KeyVault(SecretUri=https://"$keyVaultName".vault.azure.net/secrets/"$@"/)"
}

function intro {
	# Display the intro - give the user a chance to cancel 
	#
	echo " "
	echo "FHIR-SyncAgent Application setup script... "
	echo " - Prerequisite:  Azure API for FHIR must be installed "
	echo " - Prerequisite:  Microsoft FHIR-Proxy must be installed with KeyVault"
	echo " - Prerequisite:  Microsoft FHIR-SyncAgent deployment should be finished w/o errors (deploySyncAgent.bash)"
	echo " - Prerequisite:  Dataverse (a.k.a., CDS) Tenant and Application ID information is needed "
	echo " "
	echo " Information needed by this script"
	echo " - KeyVault Name installed with FHIR-Proxy"
	echo " - DV Instance URL... (URL of the Dataverse instance)" 
	echo " - DV Tenant ID... (Dataverse Tenant ID), "
	echo " - DV Client ID... (Application ID of the Application made in the Dataverse Tenant)" 
	echo " - DV Client Secret... (Application Secret of the Application made in the Dataverse Tenant)"
	echo " "
	read -p 'Press Enter to continue or Ctrl+C to exit'
}

function result () {
    if [[ $1 = "ok" ]]; then
        echo -e ".......................... [ \033[32m ok \033[37m ] \r" 
      else
        echo -e ".......................... [ \033[31m failed \033[37m ] \r"
        exit 1
      fi
    echo -e "\033[37m \r"
    sleep 1
}

function get_cds_variables () {
    # function to parse the Dataverse Environment variables needed for configuration in the Dataverse portal 
    # SA-SERVICEBUSNAMESPACEDVUPDATES 
    #
    keyVaultExists=$(az keyvault list --query "[?name == '$keyVaultName'].name" --out tsv)
    if [[ -n "$keyVaultExists" ]]; then
        echo "Checking for CDS variables in $keyVaultName..."
	    set +e
        cdsUpdateConnectionString=$(az keyvault secret show --vault-name $keyVaultName --name SA-SERVICEBUSNAMESPACECDSUPDATES --query "value" --out tsv)
        if [ -n "$cdsUpdateConnectionString" ]; then
            echo "...found CDS values in "$keyVaultName"..."
            cdsServiceBusUrl=$(az keyvault secret show --vault-name $keyVaultName --name SA-SERVICEBUSNAMESPACECDSUPDATES --query "value" --out tsv | awk -F\; '{ print $1 }' | awk -F= '{ print $2 }' | sed -e 's/sb\://g' -e 's/\///g') 
            cdsServiceBusSharedAccessPolicy=$(az keyvault secret show --vault-name $keyVaultName --name SA-SERVICEBUSNAMESPACECDSUPDATES --query "value" --out tsv | awk -F\; '{print $2}' | awk -F= '{print $2}')
            cdsServiceBusSharedAccessPolicyKey=$(az keyvault secret show --vault-name $keyVaultName --name SA-SERVICEBUSNAMESPACECDSUPDATES --query "value" --out tsv | awk -F\; '{print $3}' | sed 's/SharedAccessKey=//g') ;	    
        else	
            echo "...no CDS values found in "$keyVaultName"..."
			result "fail" ;	
	    fi 
    fi
	echo " "
}

usage() { echo "Usage: $0  (optional) -a <fhirProxyAppName> -g <resourceGroupName> -k <keyVaultName> " 1>&2; exit 1; }

#########################################
#   Script Main Body (start here)
#########################################
#
# Initialize parameters specified from command line
# 
while getopts ":a:g:k:" arg; do
	case "${arg}" in
		a)
			fhirProxyAppName=${OPTARG}
			echo fhirProxyAppName = $fhirProxyAppName
			;;
		g)
			resourceGroupName=${OPTARG}
			echo resourceGroupName = $resourceGroupName
			;;
		k)
			keyVaultName=${OPTARG}
			echo keyVaultName = $keyVaultName
			;;
		*)
			echo "Invalid option: "${arg}" "${OPTARG}
			usage
			;;
		esac
done
shift $((OPTIND-1))
echo "Executing "$0"..."
echo "Checking Azure Authentication..."

# login to azure using user credentials
#
az account show 1> /dev/null

if [ $? != 0 ];
then
	az login
fi

# assign default subscription
#
defsubscriptionId=$(az account show --query "id" --out json | sed 's/"//g') 


# Call the intro function 
#
intro

# Prompt for parameters if not set on the command line
#

# technically we do not need the fhir proxy app name, but it will help with validation
if [ -z "$fhirProxyAppName" ] ; then
	echo "Enter the FHIR-Proxy application name connected to the Azure API for FHIR [typically starts with sfp]:"
	read fhirProxyAppName
	fhirProxyAppName=$fhirProxyAppName
fi


# technically we do not need the resource group for this script, but it helps with debugging
if [ -z "$resourceGroupName" ] ; then
	echo "Enter the resource group name where the FHIR-Proxy is installed  [typically the same as Azure API for FHIR]:"
	read resourceGroupName
	resourceGroupName=$resourceGroupName
fi

# we absolutely need the keyvault name
if [ -z "$keyVaultName" ] ; then
	echo "Enter the keyvault name installed by FHIR-Proxy to store/retreive FHIR-CDS SyncAgent information [typically ends with numbers]:"
	read keyVaultName
	keyVaultName=$keyVaultName
fi

# Ensure there are subscriptionId and resourcegroup names 
#
if [ -z "$fhirProxyAppName" ] || [ -z "$keyVaultName" ]; then
	echo "Either one of FHIR-Proxy App name or the KeyVault name is empty"
	result "fail"
fi

# Check if keyVault exists, load information from it and validate.  If validation fails, exit as we cannot proceed withouth the FHIP Proxy app and Keyvault information
#
echo " "
echo "   Checking keyVault ["$keyVaultName"] access and FHIR-Proxy values..."
keyVaultExists=$(az keyvault list --query "[?name == '$keyVaultName'].name" --out tsv)
if [[ -n "$keyVaultExists" ]]; then
	set +e
	echo "   ..... found ["$keyVaultName"]"
	fhirProxyHostName=$(az keyvault secret show --vault-name $keyVaultName --name FP-HOST --query "value" --out tsv)
	if [ -n "$fhirProxyHostName" ]; then
		echo "   ...found FHIR-Proxy Host ["$fhirProxyHostName"]"
        fhirProxyAppName=$(az keyvault secret show --vault-name $keyVaultName --name FP-HOST --query "value" --out tsv | awk -F. '{print $1}') 
		echo "   ...setting FHIR-Proxy App Name to ["$fhirProxyAppName"]" ;
	else	
		echo "Failed to find FHIR-Proxy Hostname in KeyVault " $keyVaultName
		result "fail";
	fi 
else
	echo "Failed to find KeyVault " $keyVaultName
	result "fail";
fi

# Prompt User for Dataverse Information 
#
echo " "
echo "Collecting the Dataverse Instance / Connection Information "
echo " "
echo "Enter the Dataverse Instance URL - aka MC4H App URL (include the https://) ["$dvInstanceUrl"]:"
	read dvInstanceUrl
	if [ -z "$dvInstanceUrl" ] ; then
		dvInstanceUrl=$dvInstanceUrl
	fi
	[[ "${dvInstanceUrl:?}" ]]

echo " "
echo "Enter the Dataverse Tenant ID ["$dvTenantId"]:"
	read dvTenantId
	if [ -z "$dvTenantId" ] ; then
		dvTenantId=$dvTenantId
	fi
	[[ "${dvTenantId:?}" ]]

echo " "
echo "Enter the Dataverse Client ID ["$dvClientId"]:"
	read dvClientId
	if [ -z "$dvClientId" ] ; then
		dvClientId=$dvClientId
	fi
	[[ "${dvClientId:?}" ]]

echo " "
echo "Enter the Dataverse Client Secret ["$dvClientSecret"]:"
	read dvClientSecret
	if [ -z "$dvClientSecret" ] ; then
		dvClientSecret=$dvClientSecret
	fi
	[[ "${dvClientSecret:?}" ]]

# Gather the FHIR-CDS SyncAgent information from the KeyVault for use in the DV Environment 
echo " "
echo "Gathering FHIR-SyncAgent information for use in the Dataverse Integration Settings (environment variables)"
get_cds_variables

#########################################
#  Store Dataverse Information in vault
#########################################
#
echo "Storing FHIR-Sync Agent and Dataverse settings in keyVault "$keyVaultName"..."
(
    echo "Storing SA-FHIRMAPPEDRESOURCES in keyVault..."
    stepresult=$(az keyvault secret set --vault-name $keyVaultName --name "SA-FHIRMAPPEDRESOURCES" --value $fhirMappedResources)

	# ---

    echo "Storing SA-CDSAUDIENCE in keyVault... "
    stepresult=$(az keyvault secret set --vault-name $keyVaultName --name "SA-CDSAUDIENCE" --value $dvInstanceUrl)

    echo "Storing SA-CDSTENANTID in keyVault... "
    stepresult=$(az keyvault secret set --vault-name $keyVaultName --name "SA-CDSTENANTID" --value $dvTenantId)

    echo "Storing SA-CDSCLIENTID in keyVault... "
    stepresult=$(az keyvault secret set --vault-name $keyVaultName --name "SA-CDSCLIENTID" --value $dvClientId)

    echo "Storing SA-CDSSECRET in keyVault... "
    stepresult=$(az keyvault secret set --vault-name $keyVaultName --name "SA-CDSSECRET" --value $dvClientSecret)

	echo " "
	echo "----------------------------------------------------------------------------------------------------------------"
	echo " Secure FHIR-SyncAgent application configuration settings are stored in KeyVault: ["$keyVaultName"]"
	echo "----------------------------------------------------------------------------------------------------------------"
	echo " "
	echo "----------------------------------------------------------------------------------------------------------------"
	echo " You need the following information to configure Dataverse Integration Settings in MC4H FHIR Sync Administration"
	echo " - Service Bus URL:  "$cdsServiceBusUrl
	echo " - Service Queue:  "$cdsServiceQueue 
	echo " - Service Bus Shared Access Policy:  "$cdsServiceBusSharedAccessPolicy
	echo " - Service Bus Shared Access Policy Key:  "$cdsServiceBusSharedAccessPolicyKey
	echo "----------------------------------------------------------------------------------------------------------------"
	echo " "
	echo "****************************************************************************************************************"
	echo " "

)
	
if [ $?  != 0 ];
 then
	echo "FHIR-SyncAgent application setup had errors. Please review the outcomes above to understand what failed"
fi
