#!/bin/bash
set -euo pipefail
IFS=$'\n\t'

# -e: immediately exit if any command has a non-zero exit status
# -o: prevents errors in a pipeline from being masked
# IFS new value is less likely to cause confusing bugs when looping arrays or arguments (e.g. $@)
#
# FHIR 2 CDS Sync Agent Control Script --- Author Steve Ordahl Principal Architect Health Data Platform
#

# Script will enable / disable the sync agent by removing the Proxy Post Processor from the Proxy App Configuration file.
#


# Script variables 
declare fhirProxyAppName=""
declare resourceGroupName=""
declare controlVar=""
declare stepresult=""

#########################################
#  Script Functions 
#########################################

function intro {
	# Display the intro - give the user a chance to cancel 
	#
	echo " "
	echo "FHIR-SyncAgent Control Agent... "
	echo " - Prerequisite:  Azure API for FHIR must be installed"
	echo " - Prerequisite:  HealthArchitectures FHIR-Proxy must be installed with KeyVault"
	echo " "
	read -p 'Press Enter to continue, or Ctrl+C to exit'
}


function result () {
    if [[ $1 = "ok" ]]; then
        echo -e "............................ [ \033[32m ok \033[37m ] \r" 
      else
        echo -e "............................ [ \033[31m failed \033[37m ] \r"
        exit 1
      fi
    echo -e "\033[37m \r"
    sleep 2
}


usage() { echo "Usage: $0 -a <fhir-poxy appname> -g <resourceGroupName> -c <enable or disable>" 1>&2; exit 1; }

#########################################
#   Script Main Body (start here)
#########################################

# Initialize parameters specified from command line

while getopts ":a:g:c:" arg; do
	case "${arg}" in
		a)
			fhirProxyAppName=${OPTARG}
			;;
		g)
			resourceGroupName=${OPTARG}
			;;
		c)
			controlVar=${OPTARG}
			;;
		*)
			echo "Invalid option: "${arg}" "${OPTARG}
			usage
			;;
		esac
done
shift $((OPTIND-1))
echo "Executing "$0"..."
echo "Checking Azure Authentication..."

# login to azure using your credentials
#
az account show 1> /dev/null

if [ $? != 0 ];
then
	az login
fi

# set default subscription information
#
defsubscriptionId=$(az account show --query "id" --out json | sed 's/"//g') 


# Call the function 
#
intro

#Prompt for common parameters if some required parameters are missing
#

if [[ -z "$fhirProxyAppName" ]]; then
	echo "Enter the FHIR-Proxy App name (typically starts with sfp)... :"
	read fhirProxyAppName
	if [ -z "$fhirProxyAppName" ] ; then
		echo "The FHIR-Proxy App must be entered"
		result "fail"
	fi
	[[ "${fhirProxyAppName:?}" ]]
fi

if [[ -z "$resourceGroupName" ]]; then
	echo "Enter a resource group name where FHIR-Proxy App is installed"
	read resourceGroupName
		if [ -z "$resourceGroupName" ] ; then
		echo "The FHIR-Proxy Resource Group name must be entered"
		result "fail"
	fi
	[[ "${resourceGroupName:?}" ]]
fi

if [[ -z "$controlVar" ]]; then
	echo "Enter Control Variable (enable or disable)"
	read controlVar
		if [ -z "$controlVar" ] ; then
		echo "The FHIR-SyncAgent control variable must be entered"
		result "fail"
	fi
	[[ "${controlVar:?}" ]]
fi


if [ -z "${fhirProxyAppName}" ] || [ -z "${controlVar}" ]; then
	echo "Either FHIR-Proxy App name or the controlVar name is empty"
    usage
fi


############################
#  Start deployment 
############################

echo "Executing $0 -a $fhirProxyAppName -g $resourceGroupName -c $controlVar"
(
	echo " "
	if [[ $controlVar = "enable" ]]; then
	    echo "Enabling the FHIR-CDS SyncAgent Post Processor in ["$fhirProxyAppName"]..."

	    stepresult=$(az functionapp config appsettings set --name $fhirProxyAppName --resource-group $resourceGroupName --settings FP-POST-PROCESSOR-TYPES=FHIRProxy.postprocessors.FHIRCDSSyncAgentPostProcess2 )

	    echo "Restarting the FHIR-Proxy Function App"
	    stepresult=$(az functionapp restart --name $fhirProxyAppName --resource-group $resourceGroupName)

	    echo "Messages sent to the FHIR-Proxy app will now be sent to Dataverse" ;
	else 
   	    echo " "
	    if [[ $controlVar = "disable" ]]; then
	        echo "Disablening the FHIR-CDS SyncAgent Post Processor in ["$fhirProxyAppName"]..."

	        stepresult=$(az functionapp config appsettings delete --name $fhirProxyAppName --resource-group $resourceGroupName --settings FP-POST-PROCESSOR-TYPES=FHIRProxy.postprocessors.FHIRCDSSyncAgentPostProcess2 )

            echo "Restarting the FHIR-Proxy Function app"
	        stepresult=$(az functionapp restart --name $fhirProxyAppName --resource-group $resourceGroupName)

           	echo "Messages sent to the FHIR-Proxy app will no longer be sent to Dataverse"
	    fi
	fi

	echo "************************************************************************************************************"
	echo " FHIR-SyncAgent has been set to $controlVar in FHIR-Proxy $fhirProxyAppName on "$(date)
	echo "************************************************************************************************************"

)
	
if [ $?  != 0 ];
 then
	echo "Control Agent Processing had errors. Consider manually checking the FHIR-Proxy Application Configuration manually"
fi
